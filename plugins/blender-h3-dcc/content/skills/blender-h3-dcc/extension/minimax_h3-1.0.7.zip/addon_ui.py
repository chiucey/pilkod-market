"""Blender UI layer: properties, operators, panel. Requires bpy."""
from __future__ import annotations

import os
import subprocess
import sys
import tempfile
import time
import webbrowser

import bpy

from .services import copilot_executor, preview_exporter, scene_inspector
from .services.copilot_agent import CopilotAgent
from .services import handoff_inbox
from .services.mcode_client import (
    BridgeError,
    MCodeClient,
    MCodeTimeout,
    MCodeUnavailable,
    SessionExpired,
)
from .services.result_importer import import_result_video
from .services.task_store import TaskStore
from .models.manifest import ExportManifest, FileEntry
from .utils.paths import validate_outgoing_file
from .utils.redaction import redact

ADDON_VERSION = "1.0.6"

from . import region

_UI_TEXT = {
    "zh": {
        "camera": "相机",
        "active_camera": "未选择时使用活动相机：{name}",
        "resolution": "分辨率",
        "frame_range": "帧范围",
        "defaults_panel": "默认参数",
        "fps_line": "帧率：跟随场景（{fps}fps）",
        "format_line": "格式：MP4 · H.264",
        "preview_mode": "预览模式",
        "mode_white": "白模", "mode_material": "材质预览",
        "render": "渲染",
        "rendered": "已渲染：{name}",
        "preview": "预览",
        "upload": "打开 MiniMax Code 生成",
        "duration_line": "时长：{seconds:.1f} 秒（{frames} 帧 @{fps}fps）",
        "hint_copy_1": "① 点「渲染」出白模预览",
        "hint_copy_2": "② 点「打开 MiniMax Code 生成」",
        "hint_copy_3": "③ 粘贴 {key} 发送（已自动复制）",
        "error_camera": "场景里没有相机",
        "hint_direct": "已连接 MiniMax Code：",
        "hint_direct_2": "点击后素材直接进入，自动创建任务",
    },
    "en": {
        "camera": "Camera",
        "active_camera": "Using active camera: {name}",
        "resolution": "Resolution",
        "frame_range": "Frames",
        "duration_line": "Duration: {seconds:.1f}s ({frames} frames @{fps}fps)",
        "defaults_panel": "Defaults",
        "fps_line": "FPS: follow scene ({fps}fps)",
        "format_line": "Format: MP4 · H.264",
        "preview_mode": "Preview Mode",
        "mode_white": "White Model", "mode_material": "Material Preview",
        "render": "Render",
        "rendered": "Rendered: {name}",
        "preview": "Preview",
        "upload": "Open MiniMax Code to Generate",
        "hint_copy_1": "1. Click Render for a white-model preview",
        "hint_copy_2": "2. Click the button above",
        "hint_copy_3": "3. Paste ({key}) and send (auto-copied)",
        "hint_direct": "Connected to MiniMax Code:",
        "hint_direct_2": "assets will be sent automatically",
        "error_camera": "No camera in the scene",
    },
}


def _ui_lang():
    return region.ui_lang()


def _L(_text_key, **kwargs):
    """Look up UI text and interpolate.

    The first parameter is underscore-prefixed on purpose: format placeholders
    arrive as **kwargs, and a message using {key} would otherwise collide with
    the lookup argument itself.
    """
    text = _UI_TEXT.get(_ui_lang(), _UI_TEXT["zh"]).get(_text_key, _text_key)
    return text.format(**kwargs) if kwargs else text


def _bridge_reachable():
    try:
        from .services.mcode_client import default_socket_path
        import os as _os
        return _os.path.exists(default_socket_path())
    except Exception:
        return False



_RESOLUTION_ITEMS = [
    ("360P", "360P", ""), ("480P", "480P", ""), ("720P", "720P", ""),
    ("1080P", "1080P", ""), ("original", "原始尺寸", "使用场景输出分辨率"),
]
# Dynamic enum: labels follow the Blender UI language. Blender requires the
# returned strings to stay referenced (returning fresh strings from the
# callback corrupts the dropdown), hence the module-level cache.
_MODE_ITEMS_CACHE = {}


def _mode_items(_self, _context):
    lang = _ui_lang()
    cached = _MODE_ITEMS_CACHE.get(lang)
    if cached is None:
        cached = [
            ("white_model", _L("mode_white"), "Workbench flat-shaded export"),
            ("material_preview", _L("mode_material"), "EEVEE export with materials"),
        ]
        _MODE_ITEMS_CACHE[lang] = cached
    return cached


_UPLOAD_METHOD_ITEMS_CACHE = [
    ("camera_render", "相机渲染", "从相机动画渲染预览视频"),
    ("local_upload", "本地上传", "选择一个已有的本地视频"),
]


def _upload_method_items(_self, _context):
    return _UPLOAD_METHOD_ITEMS_CACHE


def _sync_export_mode(self, _context):
    if self.upload_method == "local_upload":
        self.export_mode = "existing_video"
    else:
        self.export_mode = self.preview_mode


def _export_root() -> str:
    root = os.path.join(tempfile.gettempdir(), "minimax_h3_exports")
    os.makedirs(root, exist_ok=True)
    return root


class H3Properties(bpy.types.PropertyGroup):
    camera: bpy.props.PointerProperty(
        name="Camera", type=bpy.types.Object,
        poll=lambda self, obj: obj.type == "CAMERA",
    )
    use_scene_range: bpy.props.BoolProperty(name="Scene Frame Range", default=True)
    frame_start: bpy.props.IntProperty(name="Start", default=1)
    frame_end: bpy.props.IntProperty(name="End", default=48)
    fps_override: bpy.props.IntProperty(
        name="FPS", default=0, min=0, soft_max=120,
        description="0 = use scene FPS",
    )
    resolution: bpy.props.EnumProperty(name="Resolution", items=_RESOLUTION_ITEMS,
                                       default="720P")
    # UI-facing pair; export_mode below stays the ops-facing source of truth.
    upload_method: bpy.props.EnumProperty(
        name="Upload Method", items=_upload_method_items, default=0,
        update=_sync_export_mode)
    preview_mode: bpy.props.EnumProperty(
        name="Preview Mode", items=_mode_items, default=0,
        update=_sync_export_mode)
    output_dir: bpy.props.StringProperty(
        name="Output Dir", subtype="DIR_PATH", default="",
        description="可选：留空则使用默认临时目录")
    export_mode: bpy.props.EnumProperty(
        name="Mode",
        items=[
            ("white_model", "White Model", ""),
            ("material_preview", "Material Preview", ""),
            ("existing_video", "Existing Video", ""),
        ],
        default="white_model")
    intent: bpy.props.StringProperty(
        name="Intent", default="",
        description="Creative intent; not the final H3 prompt",
    )
    existing_video: bpy.props.StringProperty(name="Video", subtype="FILE_PATH")
    character_ref: bpy.props.StringProperty(name="Character Ref", subtype="FILE_PATH")
    scene_ref: bpy.props.StringProperty(name="Scene Ref", subtype="FILE_PATH")
    last_export_path: bpy.props.StringProperty(default="")
    last_inbox_path: bpy.props.StringProperty(default="")
    draft_id: bpy.props.StringProperty(default="")
    task_state: bpy.props.StringProperty(default="idle")
    status_line: bpy.props.StringProperty(default="")
    result_path: bpy.props.StringProperty(default="")


def _props(context) -> H3Properties:
    return context.scene.minimax_h3


def _resolved_export_params(context):
    props = _props(context)
    scene = context.scene
    camera = props.camera or scene.camera
    if props.use_scene_range:
        # Not yet synced from the scene (fresh file); mirror Jimeng: default
        # to the scene timeline until the user edits the fields.
        frame_start, frame_end = scene.frame_start, scene.frame_end
    else:
        frame_start, frame_end = props.frame_start, props.frame_end
    fps = props.fps_override or scene_inspector.effective_fps(scene)
    return camera, frame_start, frame_end, fps


def _sync_scene_frames():
    """One-shot: copy each scene's timeline into the panel fields."""
    try:
        for scene in bpy.data.scenes:
            props = scene.minimax_h3
            if props.use_scene_range:
                props.frame_start = scene.frame_start
                props.frame_end = scene.frame_end
                props.use_scene_range = False
    except Exception:
        pass
    return None  # unregister the timer


from bpy.app.handlers import persistent


@persistent
def _sync_scene_frames_on_load(_dummy):
    _sync_scene_frames()


def _set_status(props: H3Properties, state: str, line: str) -> None:
    props.task_state = state
    props.status_line = redact(line)


class H3_OT_export_preview(bpy.types.Operator):
    bl_idname = "minimax_h3.export_preview"
    bl_label = "Export Preview"
    bl_description = "Render the camera animation to a preview MP4 (no UI capture)"

    def execute(self, context):
        props = _props(context)
        camera, frame_start, frame_end, fps = _resolved_export_params(context)
        if camera is None:
            self.report({"ERROR"}, _L("error_camera"))
            return {"CANCELLED"}
        if props.export_mode == "existing_video":
            self.report({"ERROR"}, "Existing Video mode does not need an export")
            return {"CANCELLED"}
        root = bpy.path.abspath(props.output_dir) if props.output_dir else _export_root()
        os.makedirs(root, exist_ok=True)
        output = os.path.join(root, f"preview_{int(time.time())}.mp4")
        _set_status(props, "exporting", "渲染中…")
        try:
            preview_exporter.export_preview(
                scene=context.scene, camera=camera,
                frame_start=frame_start, frame_end=frame_end, fps=fps,
                resolution=props.resolution, export_mode=props.export_mode,
                output_path=output,
            )
        except preview_exporter.ExportCancelled:
            _set_status(props, "export_cancelled", "Export cancelled")
            return {"CANCELLED"}
        except preview_exporter.ExportError as exc:
            _set_status(props, "failed", f"Export failed: {exc}")
            self.report({"ERROR"}, str(exc))
            return {"CANCELLED"}
        props.last_export_path = output
        _set_status(props, "idle", _L("rendered", name=os.path.basename(output)))
        return {"FINISHED"}


class H3_OT_send_to_mcode(bpy.types.Operator):
    bl_idname = "minimax_h3.send_to_mcode"
    bl_label = "Send to M Code"
    bl_description = "Send the preview video, references and manifest to M Code"

    def execute(self, context):
        props = _props(context)
        scene = context.scene
        camera, frame_start, frame_end, fps = _resolved_export_params(context)

        if props.export_mode == "existing_video":
            video_path = bpy.path.abspath(props.existing_video)
            allowed_root = os.path.dirname(video_path) or _export_root()
        else:
            video_path = props.last_export_path
            allowed_root = _export_root()
        if not video_path or not os.path.isfile(video_path):
            self.report({"ERROR"}, "Export a preview (or pick a video) first")
            return {"CANCELLED"}

        try:
            files = [(("preview_video"), validate_outgoing_file(
                video_path, role="preview_video", allowed_root=allowed_root))]
            for role, raw in (("character_reference", props.character_ref),
                              ("scene_reference", props.scene_ref)):
                if raw:
                    path = bpy.path.abspath(raw)
                    files.append((role, validate_outgoing_file(
                        path, role=role, allowed_root=os.path.dirname(path))))
        except Exception as exc:
            self.report({"ERROR"}, redact(str(exc)))
            return {"CANCELLED"}

        info = scene_inspector.inspect_scene(scene)
        structure_evidence = None
        if props.export_mode != "existing_video":
            try:
                structure_evidence = scene_inspector.build_structure_evidence(
                    scene, camera=camera,
                    frame_start=frame_start, frame_end=frame_end,
                )
            except scene_inspector.SceneEvidenceError as exc:
                self.report({"ERROR"}, redact(str(exc)))
                return {"CANCELLED"}
        manifest = ExportManifest(
            addon_version=ADDON_VERSION,
            blender_version=info["blender_version"],
            os_name=info["os_name"], arch=info["arch"],
            scene_name=info["scene_name"],
            camera_name=camera.name if camera else "",
            frame_start=frame_start, frame_end=frame_end, fps=fps,
            resolution=props.resolution, export_mode=props.export_mode,
            duration_seconds=max(frame_end - frame_start + 1, 1) / max(fps, 1),
            intent=props.intent,
            files=[FileEntry(role=role, name=i.name, size_bytes=i.size_bytes,
                             sha256=i.sha256, mime=i.mime) for role, i in files],
            structure_evidence=structure_evidence,
        )
        try:
            manifest.validate()
        except Exception as exc:
            self.report({"ERROR"}, str(exc))
            return {"CANCELLED"}

        client = MCodeClient()
        _set_status(props, "uploading", "Sending to M Code…")
        try:
            session = client.create_session(
                addon_version=ADDON_VERSION,
                blender_version=info["blender_version"],
            )
            draft = client.submit_draft(
                session,
                manifest_payload=manifest.to_payload(),
                manifest_hash=manifest.content_hash(),
                files=[{"role": role, "path": i.path, "sha256": i.sha256,
                        "size_bytes": i.size_bytes, "mime": i.mime}
                       for role, i in files],
            )
        except MCodeUnavailable:
            # Bridge not shipped in this M Code build: fall back to the
            # inbox hand-off (copy assets, focus M Code, clipboard command).
            try:
                folder, hint = handoff_inbox.hand_off(
                    manifest.to_json_bytes().decode("utf-8"),
                    [(role, i.path) for role, i in files],
                    props.intent,
                )
            except Exception as exc:
                _set_status(props, "failed", redact(str(exc)))
                self.report({"ERROR"}, redact(str(exc)))
                return {"CANCELLED"}
            props.draft_id = ""
            props.last_inbox_path = folder
            _set_status(props, "handed_off", hint)
            self.report({"INFO"}, hint)
            return {"FINISHED"}
        except MCodeTimeout:
            _set_status(props, "failed", "M Code timed out")
            self.report({"ERROR"}, "M Code did not answer in time")
            return {"CANCELLED"}
        except BridgeError as exc:
            _set_status(props, "failed", f"Bridge error: {exc.code}")
            self.report({"ERROR"}, redact(str(exc)))
            return {"CANCELLED"}

        props.draft_id = str(draft.get("draft_id", ""))
        _set_status(props, str(draft.get("state", "draft_created")),
                    f"Draft {props.draft_id} created")
        TaskStore().record_draft(
            draft_id=props.draft_id, state=props.task_state,
            deep_link=str(draft.get("deep_link", "")),
            scene_name=info["scene_name"],
            created_at_ms=int(time.time() * 1000),
        )
        deep_link = str(draft.get("deep_link", ""))
        if deep_link.startswith("minimax"):
            webbrowser.open(deep_link)
        return {"FINISHED"}


class H3_OT_refresh_status(bpy.types.Operator):
    bl_idname = "minimax_h3.refresh_status"
    bl_label = "Refresh Status"
    bl_description = "Query M Code for the current task state"

    def execute(self, context):
        props = _props(context)
        if not props.draft_id:
            latest = TaskStore().latest_draft()
            if latest:
                props.draft_id = latest["draft_id"]
        if not props.draft_id:
            self.report({"INFO"}, "No draft to query")
            return {"CANCELLED"}
        client = MCodeClient()
        try:
            session = client.create_session(
                addon_version=ADDON_VERSION,
                blender_version=bpy.app.version_string,
            )
            status = client.task_status(session, draft_id=props.draft_id)
        except (MCodeUnavailable, MCodeTimeout, BridgeError) as exc:
            _set_status(props, props.task_state, redact(str(exc)))
            return {"CANCELLED"}
        state = str(status.get("state", "unknown"))
        _set_status(props, state, f"Task {props.draft_id}: {state}")
        TaskStore().update_state(props.draft_id, state)
        result = status.get("result")
        if isinstance(result, dict) and result.get("path"):
            props.result_path = str(result["path"])
        return {"FINISHED"}


class H3_OT_import_result(bpy.types.Operator):
    bl_idname = "minimax_h3.import_result"
    bl_label = "Import Result"
    bl_description = "Import the finished video into the Video Sequencer"

    def execute(self, context):
        props = _props(context)
        if not props.result_path or not os.path.isfile(props.result_path):
            self.report({"ERROR"}, "No finished result available yet")
            return {"CANCELLED"}
        name = import_result_video(props.result_path, scene=context.scene)
        _set_status(props, "completed", f"Imported strip {name}")
        return {"FINISHED"}


# Module-level so start/stop share it; never persisted, never in scene data.
_COPILOT = {"agent": None, "client": None, "poll": None}
_COPILOT_POLL_INTERVAL_S = 2.0


def _copilot_running() -> bool:
    return _COPILOT["poll"] is not None


class H3_OT_copilot_start(bpy.types.Operator):
    bl_idname = "minimax_h3.copilot_start"
    bl_label = "Start Copilot"
    bl_description = (
        "Poll M Code for copilot commands. Scripts only run after you "
        "approve them in M Code"
    )

    def execute(self, context):
        if _copilot_running():
            self.report({"INFO"}, "Copilot is already running")
            return {"CANCELLED"}
        client = MCodeClient()
        try:
            session = client.create_session(
                addon_version=ADDON_VERSION,
                blender_version=bpy.app.version_string,
            )
        except (MCodeUnavailable, MCodeTimeout, BridgeError) as exc:
            self.report({"ERROR"}, redact(str(exc)))
            return {"CANCELLED"}
        agent = CopilotAgent(
            client=client,
            session=session,
            handlers=copilot_executor.default_handlers(),
        )

        def _poll():
            if not _copilot_running():
                return None  # unregistered via stop
            try:
                # Drain the queue; commands were confirmed on the M Code side.
                while agent.poll_once():
                    pass
            except SessionExpired:
                try:
                    agent.session = client.create_session(
                        addon_version=ADDON_VERSION,
                        blender_version=bpy.app.version_string,
                    )
                except (MCodeUnavailable, MCodeTimeout, BridgeError):
                    pass
            except (MCodeUnavailable, MCodeTimeout, BridgeError):
                pass  # bridge away; keep polling quietly
            return _COPILOT_POLL_INTERVAL_S

        _COPILOT["agent"] = agent
        _COPILOT["client"] = client
        _COPILOT["poll"] = _poll
        bpy.app.timers.register(_poll, first_interval=1.0)
        return {"FINISHED"}


class H3_OT_copilot_stop(bpy.types.Operator):
    bl_idname = "minimax_h3.copilot_stop"
    bl_label = "Stop Copilot"

    def execute(self, context):
        if not _copilot_running():
            self.report({"INFO"}, "Copilot is not running")
            return {"CANCELLED"}
        poll = _COPILOT["poll"]
        _COPILOT["agent"] = None
        _COPILOT["client"] = None
        _COPILOT["poll"] = None
        if bpy.app.timers.is_registered(poll):
            bpy.app.timers.unregister(poll)
        return {"FINISHED"}


class H3_OT_open_mcode(bpy.types.Operator):
    bl_idname = "minimax_h3.open_mcode"
    bl_label = "Open M Code"

    def execute(self, context):
        if handoff_inbox.bring_mcode_to_front():
            return {"FINISHED"}
        self.report({"ERROR"}, "MiniMax Code is not installed or could not be opened")
        return {"CANCELLED"}


class H3_OT_sync_frame_range(bpy.types.Operator):
    bl_idname = "minimax_h3.sync_frame_range"
    bl_label = "使用场景帧范围"
    bl_description = "把帧范围重置为场景时间轴的起止帧"

    def execute(self, context):
        props = _props(context)
        props.frame_start = context.scene.frame_start
        props.frame_end = context.scene.frame_end
        props.use_scene_range = False
        return {"FINISHED"}


class H3_OT_preview_video(bpy.types.Operator):
    bl_idname = "minimax_h3.preview_video"
    bl_label = "预览"
    bl_description = "用系统播放器打开视频"

    @classmethod
    def poll(cls, context):
        props = _props(context)
        path = (bpy.path.abspath(props.existing_video)
                if props.upload_method == "local_upload"
                else props.last_export_path)
        return bool(path) and os.path.isfile(path)

    def execute(self, context):
        props = _props(context)
        path = (bpy.path.abspath(props.existing_video)
                if props.upload_method == "local_upload"
                else props.last_export_path)
        if sys.platform == "darwin":
            subprocess.Popen(["open", path])
        elif os.name == "nt":
            os.startfile(path)  # type: ignore[attr-defined]
        else:
            subprocess.Popen(["xdg-open", path])
        return {"FINISHED"}


class H3_OT_open_folder(bpy.types.Operator):
    bl_idname = "minimax_h3.open_folder"
    bl_label = "打开所在文件夹"
    bl_description = "在文件管理器中打开该文件所在的文件夹"

    path: bpy.props.StringProperty(default="")
    reveal: bpy.props.BoolProperty(default=True)

    def execute(self, context):
        target = self.path
        if not target or not os.path.exists(target):
            self.report({"ERROR"}, "路径不存在：{0}".format(target))
            return {"CANCELLED"}
        if sys.platform == "darwin":
            args = ["open", "-R", target] if self.reveal else ["open", target]
            subprocess.Popen(args)
        elif os.name == "nt":
            if self.reveal and os.path.isfile(target):
                subprocess.Popen(["explorer", "/select,", target])
            else:
                os.startfile(target)  # type: ignore[attr-defined]
        else:
            folder = os.path.dirname(target) if os.path.isfile(target) else target
            subprocess.Popen(["xdg-open", folder])
        return {"FINISHED"}


class H3_OT_export_and_send(bpy.types.Operator):
    bl_idname = "minimax_h3.export_and_send"
    bl_label = "Render & Send to M Code"
    bl_description = "Export the preview and hand it to M Code in one step"

    def execute(self, context):
        result = bpy.ops.minimax_h3.export_preview()
        if "FINISHED" not in result:
            return result
        return bpy.ops.minimax_h3.send_to_mcode()


class H3_PT_panel(bpy.types.Panel):
    bl_idname = "H3_PT_panel"
    bl_label = "MiniMax H3"
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = region.PANEL_CATEGORY

    def draw(self, context):
        layout = self.layout
        props = _props(context)
        scene = context.scene

        layout.prop(props, "camera", text=_L("camera"))
        if props.camera is None and scene.camera is not None:
            hint = layout.row()
            hint.active = False
            hint.label(text=_L("active_camera", name=scene.camera.name))

        layout.prop(props, "resolution", text=_L("resolution"))

        row = layout.row(align=True)
        row.label(text=_L("frame_range"))
        row.prop(props, "frame_start", text="")
        row.prop(props, "frame_end", text="")
        row.operator(H3_OT_sync_frame_range.bl_idname,
                     text="", icon="FILE_REFRESH")

        _, frame_start, frame_end, fps = _resolved_export_params(context)
        frames = max(0, int(frame_end) - int(frame_start) + 1)
        dur = layout.row()
        dur.active = False
        dur.label(text=_L("duration_line",
                          seconds=frames / max(fps, 1),
                          frames=frames, fps=fps))

        header, body = layout.panel("minimax_h3_defaults", default_closed=True)
        header.label(text=_L("defaults_panel"))
        if body:
            col = body.column()
            col.active = False
            col.label(text=_L("fps_line",
                              fps=scene_inspector.effective_fps(scene)))
            col.label(text=_L("format_line"))
            body.prop(props, "preview_mode", text=_L("preview_mode"))

        go = layout.column()
        go.scale_y = 1.5
        go.operator(H3_OT_export_preview.bl_idname,
                    text=_L("render"), icon="RENDER_ANIMATION")

        exported = bool(props.last_export_path) and os.path.isfile(
            props.last_export_path)
        if exported:
            row = layout.row(align=True)
            done = row.row()
            done.active = False
            done.label(text=_L("rendered",
                               name=os.path.basename(props.last_export_path)))
            row.operator(H3_OT_preview_video.bl_idname,
                         text="", icon="PLAY")
            reveal = row.operator(H3_OT_open_folder.bl_idname,
                                  text="", icon="FILE_FOLDER")
            reveal.path = props.last_export_path
            reveal.reveal = True

        up = layout.column()
        up.scale_y = 1.5
        up.enabled = exported
        up.operator(H3_OT_send_to_mcode.bl_idname,
                    text=_L("upload"), icon="EXPORT")

        note = layout.box()
        col = note.column()
        if _bridge_reachable():
            col.label(text=_L("hint_direct"), icon="INFO")
            col.label(text=_L("hint_direct_2"), icon="BLANK1")
        else:
            col.label(text=_L("hint_copy_1"), icon="INFO")
            col.label(text=_L("hint_copy_2"), icon="BLANK1")
            paste_key = "⌘V" if sys.platform == "darwin" else "Ctrl+V"
            col.label(text=_L("hint_copy_3", key=paste_key), icon="BLANK1")

        if props.status_line:
            status = layout.row(align=True)
            status.label(text=props.status_line, icon="CHECKMARK")
            if props.last_inbox_path and os.path.isdir(props.last_inbox_path):
                inbox = status.operator(H3_OT_open_folder.bl_idname,
                                        text="", icon="FILE_FOLDER")
                inbox.path = props.last_inbox_path
                inbox.reveal = False


_CLASSES = (
    H3Properties,
    H3_OT_export_preview,
    H3_OT_send_to_mcode,
    H3_OT_refresh_status,
    H3_OT_import_result,
    H3_OT_copilot_start,
    H3_OT_copilot_stop,
    H3_OT_open_mcode,
    H3_OT_export_and_send,
    H3_OT_sync_frame_range,
    H3_OT_preview_video,
    H3_OT_open_folder,
    H3_PT_panel,
)


def register():
    for cls in _CLASSES:
        bpy.utils.register_class(cls)
    bpy.types.Scene.minimax_h3 = bpy.props.PointerProperty(type=H3Properties)
    bpy.app.timers.register(_sync_scene_frames, first_interval=0.2)
    if _sync_scene_frames_on_load not in bpy.app.handlers.load_post:
        bpy.app.handlers.load_post.append(_sync_scene_frames_on_load)


def unregister():
    try:
        bpy.app.timers.unregister(_sync_scene_frames)
    except ValueError:
        pass  # already fired (it is one-shot) or never registered
    if _sync_scene_frames_on_load in bpy.app.handlers.load_post:
        bpy.app.handlers.load_post.remove(_sync_scene_frames_on_load)
    del bpy.types.Scene.minimax_h3
    for cls in reversed(_CLASSES):
        bpy.utils.unregister_class(cls)
