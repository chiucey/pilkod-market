"""Runtime region/locale resolution.

One build serves every market. The Marketplace treats CN/US as a submission
dimension rather than a package dimension, and the extension itself is pure
Python, so a single artifact covers cn/oversea x macOS/Windows. Anything that
used to be stamped at build time is detected here instead:

  language  - follows Blender's own UI locale
  client    - every known launch key is tried in turn, so no region probe is
              needed to open MiniMax Code
"""

from __future__ import annotations

# Launch keys, most robust first. Keep the executable name alongside each
# bundle so the launcher can prefer a client that is already running. Internal
# and release builds intentionally share ``minimax-cn://``; the scheme cannot
# distinguish them, so exact bundle identifiers must be the primary route.
MACOS_CLIENTS = (
    ("com.minimax.agent.cn", "MiniMax Code", "MiniMax Code"),
    ("com.minimax.agent.cn.internal", "MiniMax Internal Code",
     "MiniMax Internal Code"),
    ("com.minimax.agent", "MiniMax Code", "MiniMax Code"),
)
MACOS_BUNDLE_IDS = tuple(client[0] for client in MACOS_CLIENTS)
MACOS_APP_NAMES = tuple(dict.fromkeys(client[1] for client in MACOS_CLIENTS))
URL_SCHEMES = ("minimax-cn", "minimax")

APP_NAME = "MiniMax Code"

PANEL_CATEGORY = "MiniMax Code"
_PANEL_LABEL = {
    "zh": "MiniMax H3 预览渲染生成器",
    "en": "MiniMax H3 Preview Renderer",
}


def ui_lang() -> str:
    """'zh' when Blender's interface is Chinese, otherwise 'en'."""
    try:
        import bpy

        locale = bpy.app.translations.locale or ""
    except Exception:
        locale = ""
    return "zh" if locale.startswith("zh") else "en"


def panel_label() -> str:
    return _PANEL_LABEL.get(ui_lang(), _PANEL_LABEL["en"])
