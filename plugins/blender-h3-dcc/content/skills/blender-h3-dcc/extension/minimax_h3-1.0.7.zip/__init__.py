"""MiniMax H3 for Blender — camera-driven preview export to M Code.

Clean-room implementation. Blender exports and mirrors task state; M Code
owns login, prompt drafting, paid-submit confirmation and durable tasks.

This package top level stays bpy-free so models/services/utils stay
importable (and unit-testable) outside Blender. The UI layer loads lazily
inside register().
"""

ADDON_VERSION = "0.1.0"


def register():
    from . import addon_ui

    addon_ui.register()


def unregister():
    from . import addon_ui

    addon_ui.unregister()
