"""Blender-side task state mirror.

M Code owns the durable task; Blender only mirrors it. The mirror enforces
the legal transition table and fails closed on anything unknown — it must
never invent a transition that could re-trigger a paid submit.
"""
from __future__ import annotations

from enum import Enum
from typing import Dict, Set


class TaskState(Enum):
    IDLE = "idle"
    INSPECTING_SCENE = "inspecting_scene"
    EXPORTING = "exporting"
    EXPORT_CANCELLED = "export_cancelled"
    DRAFT_CREATED = "draft_created"
    AWAITING_USER_CONFIRMATION = "awaiting_user_confirmation"
    UPLOADING = "uploading"
    SUBMITTED = "submitted"
    QUEUED = "queued"
    GENERATING = "generating"
    DOWNLOADING = "downloading"
    COMPLETED = "completed"
    FAILED = "failed"
    CANCELLED = "cancelled"


LEGAL_TRANSITIONS: Dict[TaskState, Set[TaskState]] = {
    TaskState.IDLE: {TaskState.INSPECTING_SCENE},
    TaskState.INSPECTING_SCENE: {TaskState.EXPORTING, TaskState.IDLE, TaskState.FAILED},
    TaskState.EXPORTING: {
        TaskState.EXPORT_CANCELLED, TaskState.DRAFT_CREATED, TaskState.FAILED,
    },
    TaskState.EXPORT_CANCELLED: {TaskState.IDLE},
    TaskState.DRAFT_CREATED: {
        TaskState.AWAITING_USER_CONFIRMATION, TaskState.CANCELLED, TaskState.FAILED,
    },
    TaskState.AWAITING_USER_CONFIRMATION: {
        TaskState.UPLOADING, TaskState.CANCELLED, TaskState.FAILED,
    },
    TaskState.UPLOADING: {TaskState.SUBMITTED, TaskState.CANCELLED, TaskState.FAILED},
    TaskState.SUBMITTED: {
        TaskState.QUEUED, TaskState.GENERATING, TaskState.CANCELLED, TaskState.FAILED,
    },
    TaskState.QUEUED: {TaskState.GENERATING, TaskState.CANCELLED, TaskState.FAILED},
    TaskState.GENERATING: {
        TaskState.DOWNLOADING, TaskState.COMPLETED, TaskState.CANCELLED, TaskState.FAILED,
    },
    TaskState.DOWNLOADING: {TaskState.COMPLETED, TaskState.FAILED},
    TaskState.COMPLETED: {TaskState.IDLE},
    TaskState.FAILED: {TaskState.IDLE},
    TaskState.CANCELLED: {TaskState.IDLE},
}


class IllegalTransition(RuntimeError):
    pass


class UnknownStateError(ValueError):
    pass


class TaskMirror:
    def __init__(self) -> None:
        self._state = TaskState.IDLE

    @classmethod
    def at(cls, state: TaskState) -> "TaskMirror":
        mirror = cls()
        mirror._state = state
        return mirror

    @property
    def state(self) -> TaskState:
        return self._state

    def transition(self, target: TaskState) -> None:
        if target not in LEGAL_TRANSITIONS[self._state]:
            raise IllegalTransition(
                f"illegal transition {self._state.value} -> {target.value}"
            )
        self._state = target

    def apply_wire_state(self, wire_value: str) -> None:
        """Apply a state reported by M Code. Fail closed on unknown values."""
        try:
            target = TaskState(wire_value)
        except ValueError:
            raise UnknownStateError(f"unknown wire state: {wire_value!r}") from None
        if target == self._state:
            return
        self.transition(target)
