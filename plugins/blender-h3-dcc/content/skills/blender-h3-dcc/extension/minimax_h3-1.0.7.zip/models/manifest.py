"""Export manifest (v1 single clip / v2 multi-shot / v3 structure evidence) sent
from Blender to the M Code DCC bridge.

Design constraints:
- Deterministic serialization (sorted keys, compact separators) so the same
  export always produces the same bytes and the same content hash. v1
  payloads stay byte-identical to the pre-shots implementation: `shots`
  and `shot_index` keys are only emitted for v2 manifests.
- Pure stdlib, no bpy import — unit-testable outside Blender.

Schema v2 (multi-shot):
- `shots`: ordered list of ShotEntry (index/camera/frame range/fps).
- Every `preview_video` file carries a `shot_index`; together they must
  cover exactly 0..len(shots)-1. Reference files never carry one.
- Top-level frame_start/frame_end must equal the overall shot span.
"""
from __future__ import annotations

import hashlib
import json
import re
from dataclasses import dataclass, field, asdict
from typing import Any, Dict, List, Optional

MANIFEST_SCHEMA_VERSION = 3
SUPPORTED_SCHEMA_VERSIONS = (1, 2, 3)
MAX_SHOTS = 24
MAX_STRUCTURE_OBJECTS = 256
MAX_STRUCTURE_SAMPLES = 12

RESOLUTIONS = ("360P", "480P", "720P", "1080P", "original")
EXPORT_MODES = ("white_model", "material_preview", "existing_video")
PREVIEW_ROLE = "preview_video"
REFERENCE_ROLES = ("character_reference", "scene_reference", "style_reference")
ALLOWED_ROLES = (PREVIEW_ROLE,) + REFERENCE_ROLES

MAX_INTENT_CHARS = 5000
_SHA256_RE = re.compile(r"^[0-9a-f]{64}$")


class ManifestError(ValueError):
    """Raised when a manifest fails validation or deserialization."""


@dataclass
class FileEntry:
    role: str
    name: str
    size_bytes: int
    sha256: str
    mime: str
    # v2 only: which shot a preview_video belongs to. Must stay None on v1
    # manifests and on reference files so v1 serialization is unchanged.
    shot_index: Optional[int] = None

    def validate(self) -> None:
        if self.role not in ALLOWED_ROLES:
            raise ManifestError(f"unknown file role: {self.role!r}")
        if not self.name or "/" in self.name or "\\" in self.name:
            raise ManifestError(f"invalid file name: {self.name!r}")
        if not isinstance(self.size_bytes, int) or self.size_bytes <= 0:
            raise ManifestError(f"invalid size for {self.name!r}: {self.size_bytes}")
        if not isinstance(self.sha256, str) or not _SHA256_RE.match(self.sha256):
            raise ManifestError(f"invalid sha256 for {self.name!r}")
        if not self.mime or "/" not in self.mime:
            raise ManifestError(f"invalid mime for {self.name!r}: {self.mime!r}")
        if self.shot_index is not None and (
            not isinstance(self.shot_index, int) or self.shot_index < 0
        ):
            raise ManifestError(f"invalid shot_index for {self.name!r}")


@dataclass
class ShotEntry:
    index: int
    camera_name: str
    frame_start: int
    frame_end: int
    fps: int

    def validate(self) -> None:
        if not isinstance(self.index, int) or self.index < 0:
            raise ManifestError(f"invalid shot index: {self.index!r}")
        if not self.camera_name:
            raise ManifestError(f"shot {self.index} missing camera_name")
        if not isinstance(self.frame_start, int) or not isinstance(self.frame_end, int):
            raise ManifestError(f"shot {self.index} frame range must be integers")
        if self.frame_end < self.frame_start:
            raise ManifestError(
                f"shot {self.index}: frame_end ({self.frame_end}) < "
                f"frame_start ({self.frame_start})"
            )
        if not isinstance(self.fps, int) or self.fps <= 0:
            raise ManifestError(f"shot {self.index}: fps must be positive")


@dataclass
class ExportManifest:
    addon_version: str
    blender_version: str
    os_name: str
    arch: str
    scene_name: str
    camera_name: str
    frame_start: int
    frame_end: int
    fps: int
    resolution: str
    export_mode: str
    duration_seconds: float
    intent: str
    files: List[FileEntry] = field(default_factory=list)
    shots: Optional[List[ShotEntry]] = None
    structure_evidence: Optional[Dict[str, Any]] = None
    # 0 = auto-stamp: v3 with structure evidence; otherwise legacy v1/v2.
    schema_version: int = 0

    def __post_init__(self) -> None:
        if self.schema_version == 0:
            self.schema_version = 3 if self.structure_evidence else (2 if self.shots else 1)

    # -- validation ------------------------------------------------------
    def validate(self) -> None:
        if self.schema_version not in SUPPORTED_SCHEMA_VERSIONS:
            raise ManifestError(f"unsupported schema_version: {self.schema_version}")
        for attr in ("addon_version", "blender_version", "os_name", "arch",
                     "scene_name", "camera_name"):
            if not getattr(self, attr):
                raise ManifestError(f"missing field: {attr}")
        if not isinstance(self.frame_start, int) or not isinstance(self.frame_end, int):
            raise ManifestError("frame range must be integers")
        if self.frame_end < self.frame_start:
            raise ManifestError(
                f"frame_end ({self.frame_end}) < frame_start ({self.frame_start})"
            )
        if not isinstance(self.fps, int) or self.fps <= 0:
            raise ManifestError(f"fps must be a positive integer, got {self.fps}")
        if self.resolution not in RESOLUTIONS:
            raise ManifestError(f"unknown resolution: {self.resolution!r}")
        if self.export_mode not in EXPORT_MODES:
            raise ManifestError(f"unknown export_mode: {self.export_mode!r}")
        if self.duration_seconds <= 0:
            raise ManifestError(f"invalid duration: {self.duration_seconds}")
        if len(self.intent) > MAX_INTENT_CHARS:
            raise ManifestError("intent too long")
        for entry in self.files:
            entry.validate()
        if self.schema_version == 1:
            self._validate_v1()
        elif self.schema_version == 2:
            self._validate_v2()
        else:
            if self.shots:
                self._validate_v2()
            else:
                self._validate_v1()
            self._validate_structure_evidence()

    def _validate_v1(self) -> None:
        if self.shots:
            raise ManifestError("schema v1 manifests must not carry shots")
        for entry in self.files:
            if entry.shot_index is not None:
                raise ManifestError(
                    f"schema v1 files must not carry shot_index: {entry.name!r}"
                )
        previews = [f for f in self.files if f.role == PREVIEW_ROLE]
        if len(previews) != 1:
            raise ManifestError(
                f"manifest requires exactly one {PREVIEW_ROLE}, got {len(previews)}"
            )

    def _validate_structure_evidence(self) -> None:
        evidence = self.structure_evidence
        if not isinstance(evidence, dict):
            raise ManifestError("schema v3 requires structure_evidence")
        required = {"schema_version", "sample_frames", "camera_samples", "objects"}
        if set(evidence) != required:
            raise ManifestError("structure_evidence has wrong fields")
        if evidence.get("schema_version") != 1:
            raise ManifestError("unsupported structure_evidence schema_version")
        sample_frames = evidence.get("sample_frames")
        camera_samples = evidence.get("camera_samples")
        objects = evidence.get("objects")
        if not isinstance(sample_frames, list) or not sample_frames:
            raise ManifestError("structure_evidence.sample_frames must be non-empty")
        if len(sample_frames) > MAX_STRUCTURE_SAMPLES:
            raise ManifestError("too many structure evidence samples")
        if any(not isinstance(value, int) for value in sample_frames):
            raise ManifestError("structure evidence sample frames must be integers")
        if sample_frames != sorted(set(sample_frames)):
            raise ManifestError("structure evidence sample frames must be unique and sorted")
        if not isinstance(camera_samples, list) or len(camera_samples) != len(sample_frames):
            raise ManifestError("camera_samples must match sample_frames")
        if not isinstance(objects, list) or not objects:
            raise ManifestError("structure_evidence.objects must be non-empty")
        if len(objects) > MAX_STRUCTURE_OBJECTS:
            raise ManifestError("too many structure evidence objects")
        source_ids = []
        for item in objects:
            if not isinstance(item, dict):
                raise ManifestError("structure evidence objects must be objects")
            source_id = item.get("source_id")
            if not isinstance(source_id, str) or not source_id:
                raise ManifestError("structure evidence object missing source_id")
            source_ids.append(source_id)
            samples = item.get("samples")
            if not isinstance(samples, list) or len(samples) != len(sample_frames):
                raise ManifestError(f"structure object {source_id} samples must match sample_frames")
        if len(source_ids) != len(set(source_ids)):
            raise ManifestError("structure evidence source_ids must be unique")

    def _validate_v2(self) -> None:
        if not self.shots:
            raise ManifestError("schema v2 manifests require a non-empty shots list")
        if len(self.shots) > MAX_SHOTS:
            raise ManifestError(
                f"too many shots: {len(self.shots)} (max {MAX_SHOTS})"
            )
        for position, shot in enumerate(self.shots):
            shot.validate()
            if shot.index != position:
                raise ManifestError(
                    f"shot indexes must be contiguous from 0: position "
                    f"{position} has index {shot.index}"
                )
        for prev, cur in zip(self.shots, self.shots[1:]):
            if cur.frame_start <= prev.frame_end:
                raise ManifestError(
                    f"shots {prev.index} and {cur.index} overlap or are unordered"
                )
        if (self.frame_start != self.shots[0].frame_start
                or self.frame_end != self.shots[-1].frame_end):
            raise ManifestError(
                "top-level frame range must equal the overall shot span"
            )
        seen_indexes = set()
        for entry in self.files:
            if entry.role == PREVIEW_ROLE:
                if entry.shot_index is None:
                    raise ManifestError(
                        f"v2 preview_video needs a shot_index: {entry.name!r}"
                    )
                if entry.shot_index >= len(self.shots):
                    raise ManifestError(
                        f"shot_index {entry.shot_index} out of range for "
                        f"{len(self.shots)} shots"
                    )
                if entry.shot_index in seen_indexes:
                    raise ManifestError(
                        f"duplicate shot_index {entry.shot_index}"
                    )
                seen_indexes.add(entry.shot_index)
            elif entry.shot_index is not None:
                raise ManifestError(
                    f"reference files must not carry shot_index: {entry.name!r}"
                )
        if len(seen_indexes) != len(self.shots):
            raise ManifestError(
                f"expected one {PREVIEW_ROLE} per shot "
                f"({len(self.shots)}), got {len(seen_indexes)}"
            )

    # -- serialization ---------------------------------------------------
    def to_payload(self) -> dict:
        payload = asdict(self)
        files = []
        for entry in payload["files"]:
            if entry.get("shot_index") is None:
                entry.pop("shot_index", None)
            files.append(entry)
        payload["files"] = files
        if payload.get("shots") is None:
            payload.pop("shots", None)
        if payload.get("structure_evidence") is None:
            payload.pop("structure_evidence", None)
        return payload

    def to_json_bytes(self) -> bytes:
        self.validate()
        return json.dumps(
            self.to_payload(), sort_keys=True, separators=(",", ":"),
            ensure_ascii=False,
        ).encode("utf-8")

    def content_hash(self) -> str:
        return hashlib.sha256(self.to_json_bytes()).hexdigest()

    @classmethod
    def from_json_bytes(cls, data: bytes) -> "ExportManifest":
        try:
            payload = json.loads(data.decode("utf-8"))
        except (UnicodeDecodeError, json.JSONDecodeError) as exc:
            raise ManifestError(f"manifest is not valid JSON: {exc}") from exc
        if not isinstance(payload, dict):
            raise ManifestError("manifest must be a JSON object")
        try:
            files = [FileEntry(**f) for f in payload.pop("files", [])]
            raw_shots = payload.pop("shots", None)
            structure_evidence = payload.pop("structure_evidence", None)
            shots = ([ShotEntry(**s) for s in raw_shots]
                     if raw_shots is not None else None)
            manifest = cls(
                files=files, shots=shots,
                structure_evidence=structure_evidence, **payload,
            )
        except TypeError as exc:
            raise ManifestError(f"manifest has wrong shape: {exc}") from exc
        manifest.validate()
        return manifest
