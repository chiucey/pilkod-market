"""Material spec v1: structured Principled BSDF description (pure stdlib).

The spec is the contract between M Code (which will eventually generate
textures) and the Blender-side material_builder. Texture slots carry local
file paths only — this module never fetches or generates anything.

Schema (all fields except schema_version/name optional):
    {
      "schema_version": 1,
      "name": "RustyMetal",
      "base_color": [r, g, b] | [r, g, b, a],       # 0..1 floats
      "metallic": 0..1,
      "roughness": 0..1,
      "emission_color": [r, g, b] | [r, g, b, a],
      "emission_strength": >= 0,
      "textures": {                                  # png paths per slot
        "base_color" | "metallic" | "roughness" | "normal": "/path.png"
      }
    }
"""
from __future__ import annotations

import os
from typing import Any, Dict, List

SCHEMA_VERSION = 1

TEXTURE_SLOTS = ("base_color", "metallic", "roughness", "normal")

_ALLOWED_TEXTURE_EXTENSIONS = (".png",)

_DEFAULTS = {
    "base_color": [0.8, 0.8, 0.8, 1.0],
    "metallic": 0.0,
    "roughness": 0.5,
    "emission_color": [0.0, 0.0, 0.0, 1.0],
    "emission_strength": 0.0,
}


class MaterialSpecError(ValueError):
    pass


def _normalize_color(value: Any, field: str) -> List[float]:
    if not isinstance(value, (list, tuple)) or len(value) not in (3, 4):
        raise MaterialSpecError(f"{field} must be [r,g,b] or [r,g,b,a]")
    channels: List[float] = []
    for channel in value:
        if isinstance(channel, bool) or not isinstance(channel, (int, float)):
            raise MaterialSpecError(f"{field} channels must be numbers")
        number = float(channel)
        if not 0.0 <= number <= 1.0:
            raise MaterialSpecError(f"{field} channels must be within 0..1")
        channels.append(number)
    if len(channels) == 3:
        channels.append(1.0)
    return channels


def _normalize_unit_scalar(value: Any, field: str) -> float:
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        raise MaterialSpecError(f"{field} must be a number")
    number = float(value)
    if not 0.0 <= number <= 1.0:
        raise MaterialSpecError(f"{field} must be within 0..1")
    return number


def normalize_material_spec(
    spec: Any,
    *,
    check_files: bool = False,
) -> Dict[str, Any]:
    """Validate and fill defaults. Raises MaterialSpecError on any problem.

    check_files=True additionally requires every referenced texture path to
    exist as a regular file (Blender-side callers turn this on right before
    building nodes; validation of a spec that is still waiting for generated
    textures keeps it off).
    """
    if not isinstance(spec, dict):
        raise MaterialSpecError("material spec must be an object")
    if spec.get("schema_version") != SCHEMA_VERSION:
        raise MaterialSpecError(f"schema_version must be {SCHEMA_VERSION}")

    name = spec.get("name")
    if not isinstance(name, str) or not name.strip():
        raise MaterialSpecError("name must be a non-empty string")

    normalized: Dict[str, Any] = {
        "schema_version": SCHEMA_VERSION,
        "name": name.strip(),
        "base_color": _normalize_color(
            spec.get("base_color", _DEFAULTS["base_color"]), "base_color"
        ),
        "metallic": _normalize_unit_scalar(
            spec.get("metallic", _DEFAULTS["metallic"]), "metallic"
        ),
        "roughness": _normalize_unit_scalar(
            spec.get("roughness", _DEFAULTS["roughness"]), "roughness"
        ),
        "emission_color": _normalize_color(
            spec.get("emission_color", _DEFAULTS["emission_color"]), "emission_color"
        ),
    }

    emission_strength = spec.get("emission_strength", _DEFAULTS["emission_strength"])
    if isinstance(emission_strength, bool) or not isinstance(
        emission_strength, (int, float)
    ):
        raise MaterialSpecError("emission_strength must be a number")
    if float(emission_strength) < 0.0:
        raise MaterialSpecError("emission_strength must be >= 0")
    normalized["emission_strength"] = float(emission_strength)

    raw_textures = spec.get("textures", {})
    if not isinstance(raw_textures, dict):
        raise MaterialSpecError("textures must be an object")
    textures: Dict[str, str] = {}
    for slot, path in raw_textures.items():
        if slot not in TEXTURE_SLOTS:
            raise MaterialSpecError(
                f"unknown texture slot {slot!r}; allowed: {', '.join(TEXTURE_SLOTS)}"
            )
        if not isinstance(path, str) or not path.strip():
            raise MaterialSpecError(f"texture path for {slot!r} must be a string")
        ext = os.path.splitext(path)[1].lower()
        if ext not in _ALLOWED_TEXTURE_EXTENSIONS:
            raise MaterialSpecError(
                f"texture for {slot!r} must be one of {_ALLOWED_TEXTURE_EXTENSIONS}"
            )
        if check_files and not os.path.isfile(path):
            raise MaterialSpecError(f"texture file for {slot!r} not found: {path}")
        textures[slot] = path
    normalized["textures"] = textures

    return normalized
