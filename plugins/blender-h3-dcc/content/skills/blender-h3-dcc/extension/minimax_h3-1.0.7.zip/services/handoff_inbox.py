"""Fallback delivery when the M Code DCC bridge is not running.

A released M Code build has no external ingestion surface (no bridge socket,
no CLI, deep links limited to auth/payment callbacks), so a true one-click
hand-off is impossible until the bridge ships. This module gets as close as
the platform allows:

    copy assets to ~/mcode-dcc-inbox/<stamp>/  ->  bring M Code to front
    ->  put a ready-to-send instruction on the clipboard

The user pastes once in M Code and presses enter. When the bridge merges,
the send operator's primary path takes over and this module goes unused --
same button, no extension update needed.

No bpy imports; unit-testable anywhere.
"""
from __future__ import annotations

import os
import shutil
import subprocess
import sys
import time
from .. import region
from typing import Dict, List, Optional, Tuple


def inbox_root() -> str:
    return os.environ.get("MCODE_DCC_INBOX") or os.path.join(
        os.path.expanduser("~"), "mcode-dcc-inbox"
    )


def deliver(
    manifest_json: str,
    files: List[Tuple[str, str]],
    intent: str,
) -> Dict[str, str]:
    """Copy assets + manifest into a fresh inbox folder.

    files: (role, absolute_path) pairs. Returns {role: copied_path} plus
    the folder under key "".
    """
    stamp = time.strftime("%Y%m%d-%H%M%S")
    folder = os.path.join(inbox_root(), stamp)
    os.makedirs(folder, exist_ok=True)

    copied: Dict[str, str] = {"": folder}
    for role, path in files:
        ext = os.path.splitext(path)[1] or ""
        target = os.path.join(folder, f"{role}{ext}")
        shutil.copy2(path, target)
        copied[role] = target

    with open(os.path.join(folder, "manifest.json"), "w", encoding="utf-8") as fh:
        fh.write(manifest_json)
    return copied


def compose_instruction(folder: str, intent: str) -> str:
    """The one-liner that lands on the clipboard.

    Deliberately short: the workflow itself lives in the blender-h3-dcc
    skill installed in MiniMax Code, and the skill's description triggers on
    "DCC 收件夹" / "白模". Restating the whole procedure here would duplicate
    the skill and bury the user in text.
    """
    preview_path = os.path.join(folder, "preview_video.mp4")
    if region.ui_lang() == "en":
        line = ("Use the Blender White-model Rendering plugin to process this video:\n{0}"
                .format(preview_path))
        return "{0}\nMy intent: {1}".format(line, intent) if intent else line
    line = "用「Blender 白模渲染」插件处理这个 Blender 白模视频：\n{0}".format(preview_path)
    return "{0}\n我的创作意图：{1}".format(line, intent) if intent else line


def set_clipboard(text: str) -> bool:
    try:
        if sys.platform == "darwin":
            # pbcopy decodes stdin per LANG; Blender's env has no LANG, and
            # non-ASCII input then lands as an empty pasteboard. Force UTF-8.
            env = dict(os.environ, LANG="en_US.UTF-8")
            proc = subprocess.Popen(["pbcopy"], stdin=subprocess.PIPE, env=env)
        elif os.name == "nt":
            proc = subprocess.Popen(["clip"], stdin=subprocess.PIPE)
        else:
            proc = subprocess.Popen(
                ["xclip", "-selection", "clipboard"], stdin=subprocess.PIPE
            )
        proc.communicate(text.encode("utf-8"), timeout=5)
        return proc.returncode == 0
    except Exception:
        return False


def bring_mcode_to_front() -> bool:
    """Launch/focus the client, trying every known key until one works.

    `open -a <name>` alone is not enough: it fails when the app sits outside
    /Applications or was renamed. On macOS, prefer an already-running release
    or Internal client, then try every exact bundle identifier. URL schemes
    are only a final fallback because release and Internal share one scheme.
    """
    attempts = []
    if sys.platform == "darwin":
        clients = list(region.MACOS_CLIENTS)
        running = []
        for client in clients:
            try:
                is_running = subprocess.call(
                    ["pgrep", "-x", client[2]],
                    stdout=subprocess.DEVNULL,
                    stderr=subprocess.DEVNULL,
                ) == 0
            except Exception:
                is_running = False
            if is_running:
                running.append(client)
        ordered = running + [client for client in clients if client not in running]
        attempts += [["open", "-b", client[0]] for client in ordered]
        names = tuple(dict.fromkeys(client[1] for client in ordered))
        attempts += [["open", "-a", name] for name in names]
        attempts += [["open", "{0}://".format(s)] for s in region.URL_SCHEMES]
    elif os.name == "nt":
        attempts += [["cmd", "/c", "start", "", "{0}://".format(s)]
                     for s in region.URL_SCHEMES]
    else:
        return False

    for args in attempts:
        try:
            if subprocess.call(
                args, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL
            ) == 0:
                return True
        except Exception:
            continue
    return False


def hand_off(manifest_json: str, files: List[Tuple[str, str]],
             intent: str) -> Tuple[str, Optional[str]]:
    """Full fallback: inbox + clipboard + focus M Code.

    Returns (inbox_folder, status_hint).
    """
    copied = deliver(manifest_json, files, intent)
    folder = copied[""]
    instruction = compose_instruction(folder, intent)
    clipped = set_clipboard(instruction)
    fronted = bring_mcode_to_front()
    if clipped and fronted:
        hint = ("MiniMax Code opened — paste (Cmd+V / Ctrl+V) and send"
                if region.ui_lang() == "en"
                else "已打开 MiniMax Code，粘贴（Cmd+V）发送即可")
    elif clipped:
        hint = ("Command copied — open MiniMax Code, paste and send"
                if region.ui_lang() == "en"
                else "已复制指令，请打开 MiniMax Code 粘贴发送")
    else:
        preview_path = copied.get("preview_video") or os.path.join(folder, "preview_video.mp4")
        hint = (f"Video saved to {preview_path} — reference this file in MiniMax Code"
                if region.ui_lang() == "en"
                else f"视频已放入 {preview_path}，请在 MiniMax Code 里引用这个文件")
    return folder, hint
