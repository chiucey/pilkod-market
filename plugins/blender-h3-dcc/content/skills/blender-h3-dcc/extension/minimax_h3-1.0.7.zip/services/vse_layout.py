"""Pure VSE placement logic shared by the result importer (no bpy).

Works on duck-typed strips exposing channel / frame_final_start /
frame_final_end / name, so it is unit-testable outside Blender.

Frame semantics follow Blender's VSE: frame_final_end is exclusive, so a
strip covering shot frames [start, end] spans [start, end + 1).
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import List, Sequence


class LayoutError(ValueError):
    pass


@dataclass(frozen=True)
class SequenceItem:
    """One result video to place: its file plus the shot frame span."""

    path: str
    frame_start: int
    frame_end: int  # inclusive, like Shot.frame_end


@dataclass(frozen=True)
class StripPlacement:
    path: str
    channel: int
    frame_start: int
    frame_end_exclusive: int
    name: str


def free_channel(strips, frame_start: int, frame_end_exclusive: int) -> int:
    """First channel with no strip overlapping [frame_start, frame_end_exclusive)."""
    channel = 1
    while True:
        blocked = any(
            s.channel == channel
            and s.frame_final_start < frame_end_exclusive
            and s.frame_final_end > frame_start
            for s in strips
        )
        if not blocked:
            return channel
        channel += 1


def unique_name(strips, base: str) -> str:
    names = {s.name for s in strips}
    if base not in names:
        return base
    n = 2
    while f"{base}.{n:03d}" in names:
        n += 1
    return f"{base}.{n:03d}"


def plan_sequence_placement(
    existing_strips,
    items: Sequence[SequenceItem],
    *,
    base_name: str = "H3 Shot",
) -> List[StripPlacement]:
    """Plan gapless placement of shot results on one shared free channel.

    - Items must be ordered, non-overlapping and contiguous (each next
      frame_start == previous frame_end + 1) so the sequence is seamless.
    - The channel is the first one free across the entire span, so no
      existing strip is ever overwritten.
    """
    if not items:
        raise LayoutError("no items to place")
    for item in items:
        if item.frame_end < item.frame_start:
            raise LayoutError(
                f"item {item.path!r}: frame_end < frame_start"
            )
    for prev, cur in zip(items, items[1:]):
        if cur.frame_start != prev.frame_end + 1:
            raise LayoutError(
                f"items are not contiguous: {prev.frame_end} -> {cur.frame_start}"
            )

    span_start = items[0].frame_start
    span_end_exclusive = items[-1].frame_end + 1
    channel = free_channel(existing_strips, span_start, span_end_exclusive)

    placements: List[StripPlacement] = []
    taken_names = {s.name for s in existing_strips}
    for i, item in enumerate(items):
        base = f"{base_name} {i:03d}"
        name = base
        n = 2
        while name in taken_names:
            name = f"{base}.{n:03d}"
            n += 1
        taken_names.add(name)
        placements.append(StripPlacement(
            path=item.path,
            channel=channel,
            frame_start=item.frame_start,
            frame_end_exclusive=item.frame_end + 1,
            name=name,
        ))
    return placements
