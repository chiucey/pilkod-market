"""Batch shot export orchestration (pure stdlib, no bpy).

Drives an injected per-shot export function over an ordered shot list.
Contract:
- Shots are exported strictly in list order.
- `is_cancelled` is polled before every shot; cancellation (and any
  exception type listed in `cancel_exceptions`) raises ShotBatchCancelled.
- Any failure removes that shot's partial output file but keeps every
  already-completed shot on disk; both exception types carry the
  completed results so callers can resume or report progress.
"""
from __future__ import annotations

import os
from dataclasses import dataclass
from typing import Callable, List, Optional, Sequence, Tuple, Type

from .shot_planner import Shot


@dataclass(frozen=True)
class ShotExportResult:
    shot: Shot
    path: str


class ShotBatchCancelled(RuntimeError):
    """Batch stopped by the user; completed shots are kept."""

    def __init__(self, message: str, completed: List[ShotExportResult]) -> None:
        super().__init__(message)
        self.completed = completed


class ShotBatchError(RuntimeError):
    """One shot failed; its residue is cleaned, completed shots are kept."""

    def __init__(self, message: str, shot: Shot,
                 completed: List[ShotExportResult],
                 cause: Optional[BaseException] = None) -> None:
        super().__init__(message)
        self.shot = shot
        self.completed = completed
        self.cause = cause


def shot_output_name(shot: Shot) -> str:
    """Deterministic per-shot output file name."""
    return f"shot_{shot.index:03d}.mp4"


def _cleanup_partial(path: str) -> None:
    try:
        if os.path.isfile(path):
            os.remove(path)
    except OSError:
        pass


def export_shot_batch(
    shots: Sequence[Shot],
    *,
    export_fn: Callable[[Shot, str], str],
    output_dir: str,
    is_cancelled: Optional[Callable[[], bool]] = None,
    cancel_exceptions: Tuple[Type[BaseException], ...] = (KeyboardInterrupt,),
) -> List[ShotExportResult]:
    """Export every shot via export_fn(shot, output_path) -> path."""
    if not shots:
        raise ShotBatchError("no shots to export", shot=None, completed=[])
    os.makedirs(output_dir, exist_ok=True)

    completed: List[ShotExportResult] = []
    for shot in shots:
        if is_cancelled is not None and is_cancelled():
            raise ShotBatchCancelled(
                f"batch cancelled before shot {shot.index}", completed=completed,
            )
        output_path = os.path.join(output_dir, shot_output_name(shot))
        try:
            produced = export_fn(shot, output_path)
        except cancel_exceptions as exc:
            _cleanup_partial(output_path)
            raise ShotBatchCancelled(
                f"batch cancelled during shot {shot.index}: {exc}",
                completed=completed,
            ) from exc
        except BaseException as exc:
            _cleanup_partial(output_path)
            raise ShotBatchError(
                f"shot {shot.index} export failed: {exc}",
                shot=shot, completed=completed, cause=exc,
            ) from exc
        completed.append(ShotExportResult(shot=shot, path=produced))
    return completed
