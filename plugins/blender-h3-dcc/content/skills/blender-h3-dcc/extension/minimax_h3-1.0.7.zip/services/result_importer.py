"""Import finished H3 result videos into the Video Sequencer.

Never overwrites existing strips: picks the first fully free channel over
the target frame range and deduplicates strip names. Multi-shot sequences
are placed gaplessly on one shared channel in shot order.
"""
from __future__ import annotations

import os
from typing import List, Sequence

import bpy

from .vse_layout import (
    SequenceItem,
    free_channel,
    plan_sequence_placement,
    unique_name,
)


class ImportError_(RuntimeError):
    pass


def _sequences(scene):
    editor = scene.sequence_editor or scene.sequence_editor_create()
    # Blender 5.x renamed sequences -> strips.
    if hasattr(editor, "strips_all"):
        return editor, list(editor.strips_all)
    return editor, list(editor.sequences_all)


def _new_movie_strip(editor, *, name, filepath, channel, frame_start):
    if hasattr(editor, "strips") and hasattr(editor.strips, "new_movie"):
        return editor.strips.new_movie(
            name=name, filepath=filepath, channel=channel,
            frame_start=frame_start,
        )
    return editor.sequences.new_movie(
        name=name, filepath=filepath, channel=channel,
        frame_start=frame_start,
    )


def import_result_video(path: str, *, scene=None, frame_start: int | None = None) -> str:
    """Add the video as a new movie strip. Returns the strip name."""
    scene = scene or bpy.context.scene
    if not os.path.isfile(path):
        raise ImportError_(f"result video not found: {path!r}")

    editor, strips = _sequences(scene)
    start = frame_start if frame_start is not None else scene.frame_start

    # Probe duration via movieclip to reserve the right span.
    clip = bpy.data.movieclips.load(path)
    try:
        duration = clip.frame_duration
    finally:
        bpy.data.movieclips.remove(clip)

    channel = free_channel(strips, start, start + duration)
    name = unique_name(strips, "H3 Result")

    new_strip = _new_movie_strip(
        editor, name=name, filepath=path, channel=channel, frame_start=start,
    )
    return new_strip.name


def import_shot_sequence(items: Sequence[SequenceItem], *, scene=None) -> List[str]:
    """Place per-shot result videos gaplessly into the VSE in shot order.

    `items` must be ordered by shot and contiguous (next frame_start ==
    previous frame_end + 1). All strips land on one shared channel that is
    fully free over the whole span, so existing strips are never touched.
    Videos longer than their shot span are trimmed to it; shorter ones are
    left as-is. Returns the created strip names in shot order.
    """
    scene = scene or bpy.context.scene
    for item in items:
        if not os.path.isfile(item.path):
            raise ImportError_(f"result video not found: {item.path!r}")

    editor, strips = _sequences(scene)
    placements = plan_sequence_placement(strips, items)

    names: List[str] = []
    for placement in placements:
        strip = _new_movie_strip(
            editor,
            name=placement.name,
            filepath=placement.path,
            channel=placement.channel,
            frame_start=placement.frame_start,
        )
        # Some Blender builds auto-rename on collision; trust the editor.
        if strip.frame_final_end > placement.frame_end_exclusive:
            strip.frame_final_end = placement.frame_end_exclusive
        # new_movie may drop the strip on a different channel if it saw a
        # conflict; force the planned channel (it is free by construction).
        strip.channel = placement.channel
        names.append(strip.name)
    return names
