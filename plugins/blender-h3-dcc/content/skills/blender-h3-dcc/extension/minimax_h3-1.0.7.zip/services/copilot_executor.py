"""Blender-side executors for copilot commands (requires bpy).

One handler per command kind, matching the CopilotAgent handler contract:
callable(params) -> result dict, exceptions become failure reports.

- read_scene: read-only scene snapshot (objects/lights/cameras/render/materials)
- execute_script: user-approved bpy script in the restricted sandbox, with a
  before/after object fingerprint diff so M Code learns what actually changed
- capture_viewport: single-frame offscreen PNG render through the active
  camera (never a screen grab), restoring every touched setting
"""
from __future__ import annotations

import hashlib
import math
import os
import time
from typing import Any, Dict, Optional

import bpy

from . import script_sandbox
from .preview_exporter import RESOLUTION_PRESETS, preserved_export_settings

_DEFAULT_SCRIPT_TIMEOUT_S = 10.0
_MAX_SCRIPT_TIMEOUT_S = 60.0


# -- read_scene -----------------------------------------------------------
def read_scene(params: Dict[str, Any], *, scene=None) -> Dict[str, Any]:
    scene = scene or bpy.context.scene
    objects = []
    lights = []
    cameras = []
    for obj in scene.objects:
        entry: Dict[str, Any] = {
            "name": obj.name,
            "type": obj.type,
            "visible": not obj.hide_render,
            "location": [round(v, 6) for v in obj.location],
        }
        if obj.type == "MESH" and obj.data is not None:
            entry["polygons"] = len(obj.data.polygons)
            entry["vertices"] = len(obj.data.vertices)
            entry["materials"] = [
                slot.material.name for slot in obj.material_slots if slot.material
            ]
        objects.append(entry)
        if obj.type == "LIGHT" and obj.data is not None:
            lights.append({
                "name": obj.name,
                "light_type": obj.data.type,
                "energy": float(obj.data.energy),
                "color": [round(c, 6) for c in obj.data.color],
            })
        elif obj.type == "CAMERA" and obj.data is not None:
            cameras.append({
                "name": obj.name,
                "lens_mm": float(obj.data.lens),
                "is_active": scene.camera is not None and obj.name == scene.camera.name,
            })
    render = scene.render
    mesh_polygons = sum(o.get("polygons", 0) for o in objects)
    return {
        "scene": {
            "name": scene.name,
            "blender_version": bpy.app.version_string,
            "frame_start": scene.frame_start,
            "frame_end": scene.frame_end,
            "objects": objects,
            "object_count": len(objects),
            "total_polygons": mesh_polygons,
            "lights": lights,
            "cameras": cameras,
            "active_camera": scene.camera.name if scene.camera else None,
            "render": {
                "engine": render.engine,
                "resolution_x": render.resolution_x,
                "resolution_y": render.resolution_y,
                "fps": render.fps,
                "fps_base": render.fps_base,
            },
            "materials": [m.name for m in bpy.data.materials],
        }
    }


# -- execute_script -------------------------------------------------------
def _object_fingerprint(obj) -> str:
    parts = [
        obj.type,
        obj.data.name if obj.data is not None else "",
        obj.parent.name if obj.parent is not None else "",
        ",".join(sorted(c.name for c in obj.users_collection)),
    ]
    # location/rotation/scale update immediately after property writes;
    # matrix_world would need a depsgraph evaluation first.
    for vector in (obj.location, obj.rotation_euler, obj.scale):
        parts.extend(f"{value:.6f}" for value in vector)
    return hashlib.sha256("|".join(parts).encode("utf-8")).hexdigest()


def _scene_fingerprints(scene) -> Dict[str, str]:
    return {obj.name: _object_fingerprint(obj) for obj in scene.objects}


def execute_script(params: Dict[str, Any], *, scene=None) -> Dict[str, Any]:
    scene = scene or bpy.context.scene
    script = params.get("script")
    if not isinstance(script, str) or not script.strip():
        raise ValueError("execute_script requires a non-empty script")
    timeout_ms = params.get("timeout_ms")
    timeout_s = _DEFAULT_SCRIPT_TIMEOUT_S
    if isinstance(timeout_ms, (int, float)) and timeout_ms > 0:
        timeout_s = min(float(timeout_ms) / 1000.0, _MAX_SCRIPT_TIMEOUT_S)

    before = _scene_fingerprints(scene)
    result = script_sandbox.run_script(
        script,
        extra_globals={"bpy": bpy, "math": math, "scene": scene},
        timeout_s=timeout_s,
    )
    after = _scene_fingerprints(scene)

    added = sorted(set(after) - set(before))
    removed = sorted(set(before) - set(after))
    modified = sorted(
        name for name in set(before) & set(after) if before[name] != after[name]
    )
    payload: Dict[str, Any] = {
        "stdout": result.stdout,
        "objects_added": added,
        "objects_removed": removed,
        "objects_modified": modified,
        "affected_object_count": len(added) + len(removed) + len(modified),
    }
    if not result.ok:
        # The script failed inside the sandbox; surface it as a command
        # failure so M Code sees the (redacted) error.
        raise RuntimeError(result.error or "script failed")
    return payload


# -- capture_viewport -----------------------------------------------------
def _sha256_of(path: str) -> str:
    digest = hashlib.sha256()
    with open(path, "rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def capture_viewport(
    params: Dict[str, Any],
    *,
    scene=None,
    output_dir: Optional[str] = None,
) -> Dict[str, Any]:
    """Offscreen single-frame PNG render through the active camera."""
    scene = scene or bpy.context.scene
    if scene.camera is None:
        raise RuntimeError("scene has no active camera to capture from")
    out_dir = output_dir or os.path.join(
        os.path.expanduser("~"), ".minimax_h3", "captures"
    )
    os.makedirs(out_dir, exist_ok=True)
    output_path = os.path.join(out_dir, f"viewport_{int(time.time() * 1000)}.png")

    resolution = params.get("resolution", "720P")
    with preserved_export_settings(scene):
        render = scene.render
        if resolution != "original":
            preset = RESOLUTION_PRESETS.get(str(resolution))
            if preset is None:
                raise ValueError(f"unknown resolution preset: {resolution}")
            render.resolution_x, render.resolution_y = preset
        render.resolution_percentage = 100
        render.filepath = output_path
        render.use_file_extension = False
        render.use_overwrite = True
        if hasattr(render.image_settings, "media_type"):
            render.image_settings.media_type = "IMAGE"
        render.image_settings.file_format = "PNG"
        render.image_settings.color_mode = "RGB"
        bpy.ops.render.render(write_still=True)

    if not os.path.isfile(output_path) or os.path.getsize(output_path) == 0:
        raise RuntimeError("viewport capture produced no output file")
    return {
        "file": {
            "path": output_path,
            "sha256": _sha256_of(output_path),
            "size_bytes": os.path.getsize(output_path),
        }
    }


def default_handlers(*, scene=None, capture_dir: Optional[str] = None):
    """Handler map for CopilotAgent covering all supported command kinds."""
    return {
        "read_scene": lambda params: read_scene(params, scene=scene),
        "execute_script": lambda params: execute_script(params, scene=scene),
        "capture_viewport": lambda params: capture_viewport(
            params, scene=scene, output_dir=capture_dir
        ),
    }
