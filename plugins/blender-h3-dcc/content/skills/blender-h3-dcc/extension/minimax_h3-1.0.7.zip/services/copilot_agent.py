"""Copilot poll loop: claim commands from the M Code bridge and run them.

Pure stdlib — bpy never appears here. Handlers are injected per command
kind, so the loop is unit-testable with fakes and the same code drives both
the interactive addon (via a bpy.app.timers callback) and headless E2E.

Why polling instead of a long-lived push connection: the existing client is
a deliberately stateless connect-per-request socket client, and bpy is not
thread-safe — a push channel would need a background reader thread plus a
main-thread handoff anyway. A timer-driven claim poll keeps everything on
Blender's main thread and keeps the transport trivially testable.
"""
from __future__ import annotations

import time
from typing import Any, Callable, Dict, Mapping, Optional

from ..utils.redaction import redact

Handler = Callable[[Dict[str, Any]], Dict[str, Any]]


class CopilotAgent:
    def __init__(
        self,
        *,
        client,
        session: Mapping[str, Any],
        handlers: Mapping[str, Handler],
        logger: Optional[Callable[[str], None]] = None,
    ) -> None:
        self.client = client
        self.session = session
        self.handlers = dict(handlers)
        self._log = logger or (lambda line: None)

    def poll_once(self) -> bool:
        """Claim and execute at most one command. Returns True if one ran."""
        response = self.client.fetch_command(self.session)
        command = response.get("command")
        if not command:
            return False
        command_id = str(command.get("command_id", ""))
        kind = str(command.get("kind", ""))
        params = command.get("params") or {}
        approval_token = command.get("approval_token")
        self._log(f"copilot command claimed: {command_id} ({kind})")

        handler = self.handlers.get(kind)
        if handler is None:
            self.client.command_result(
                self.session,
                command_id=command_id,
                ok=False,
                error=f"unsupported command kind: {kind}",
                approval_token=approval_token,
            )
            return True

        try:
            result = handler(dict(params))
        except Exception as exc:  # noqa: BLE001 - report back, never crash
            self.client.command_result(
                self.session,
                command_id=command_id,
                ok=False,
                error=redact(str(exc)),
                approval_token=approval_token,
            )
            return True

        self.client.command_result(
            self.session,
            command_id=command_id,
            ok=True,
            result=result,
            approval_token=approval_token,
        )
        return True

    def run(
        self,
        *,
        max_commands: int,
        idle_timeout_s: float = 30.0,
        poll_interval_s: float = 0.2,
    ) -> int:
        """Poll until max_commands ran or the queue stayed idle too long.

        Headless helper (E2E, batch); the interactive addon calls poll_once
        from a bpy.app.timers callback instead.
        """
        handled = 0
        idle_since = time.monotonic()
        while handled < max_commands:
            if self.poll_once():
                handled += 1
                idle_since = time.monotonic()
                continue
            if time.monotonic() - idle_since >= idle_timeout_s:
                break
            time.sleep(poll_interval_s)
        return handled
