"""Shot planning from timeline markers.

Every timeline marker bound to a camera starts a shot; the shot ends the
frame before the next camera-bound marker, or at the scene frame_end.
With no camera-bound markers the plan falls back to a single shot using
the scene camera (the original single-clip behavior).

Pure stdlib: `plan_shots` is pure logic; `read_scene_shots` only reads
duck-typed attributes off a Blender scene, so neither imports bpy and
both are unit-testable outside Blender.
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Iterable, List, Optional


class ShotPlanError(ValueError):
    """Raised when no valid shot plan can be derived."""


@dataclass(frozen=True)
class MarkerInfo:
    """Minimal marker projection: frame + bound camera name (or None)."""

    frame: int
    camera_name: Optional[str]


@dataclass(frozen=True)
class Shot:
    index: int
    camera_name: str
    frame_start: int
    frame_end: int


def plan_shots(
    markers: Iterable[MarkerInfo],
    *,
    frame_start: int,
    frame_end: int,
    fallback_camera_name: Optional[str] = None,
) -> List[Shot]:
    """Derive the ordered shot list for [frame_start, frame_end].

    Rules:
    - Only markers bound to a camera count; others are ignored.
    - Markers past frame_end are dropped; markers before frame_start are
      clamped to frame_start.
    - Markers are ordered by frame. When several markers land on the same
      effective frame the last one in input order wins (matching Blender's
      camera-switch behavior where the later binding takes effect).
    - Frames before the first camera marker belong to no shot.
    - No camera markers -> single shot with the fallback camera.
    """
    if frame_end < frame_start:
        raise ShotPlanError(
            f"frame_end ({frame_end}) < frame_start ({frame_start})"
        )

    effective = []  # (clamped_frame, input_order, camera_name)
    for order, m in enumerate(markers):
        if not m.camera_name:
            continue
        if m.frame > frame_end:
            continue
        effective.append((max(m.frame, frame_start), order, m.camera_name))

    if not effective:
        if not fallback_camera_name:
            raise ShotPlanError("scene has no camera and no camera markers")
        return [Shot(index=0, camera_name=fallback_camera_name,
                     frame_start=frame_start, frame_end=frame_end)]

    effective.sort(key=lambda item: (item[0], item[1]))
    # Same effective frame: last in input order wins.
    by_frame = {}
    for frame, _order, camera_name in effective:
        by_frame[frame] = camera_name
    starts = sorted(by_frame)

    shots: List[Shot] = []
    for i, start in enumerate(starts):
        end = starts[i + 1] - 1 if i + 1 < len(starts) else frame_end
        shots.append(Shot(index=i, camera_name=by_frame[start],
                          frame_start=start, frame_end=end))
    return shots


def read_scene_shots(scene) -> List[Shot]:
    """Read timeline markers off a Blender scene and plan shots.

    Duck-typed on purpose (timeline_markers / frame_start / frame_end /
    camera attributes) so tests can drive it without bpy.
    """
    markers = [
        MarkerInfo(
            frame=m.frame,
            camera_name=m.camera.name if getattr(m, "camera", None) else None,
        )
        for m in scene.timeline_markers
    ]
    fallback = scene.camera.name if scene.camera else None
    return plan_shots(
        markers,
        frame_start=scene.frame_start,
        frame_end=scene.frame_end,
        fallback_camera_name=fallback,
    )
