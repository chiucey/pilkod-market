"""Read-only scene inspection for the panel and manifest building."""
from __future__ import annotations

import math
import platform

import bpy
from bpy_extras.object_utils import world_to_camera_view
from mathutils import Vector


STRUCTURE_EVIDENCE_SCHEMA_VERSION = 1
MAX_STRUCTURE_OBJECTS = 256
MAX_STRUCTURE_SAMPLES = 9
RENDERABLE_TYPES = {
    "MESH", "CURVE", "SURFACE", "META", "FONT", "VOLUME",
    "POINTCLOUD", "GREASEPENCIL",
}


class SceneEvidenceError(RuntimeError):
    pass


def _rounded_vector(values, digits=5):
    return [round(float(value), digits) for value in values]


def _sample_frames(frame_start: int, frame_end: int) -> list[int]:
    span = max(0, frame_end - frame_start)
    count = min(MAX_STRUCTURE_SAMPLES, max(2, math.ceil(span / 24) + 1))
    if span == 0:
        return [frame_start]
    return sorted({
        round(frame_start + span * index / (count - 1))
        for index in range(count)
    })


def _root_name(obj) -> str:
    root = obj
    while getattr(root, "parent", None) is not None:
        root = root.parent
    return root.name


def _camera_sample(camera, frame: int) -> dict:
    matrix = camera.matrix_world
    quaternion = matrix.to_quaternion()
    data = camera.data
    return {
        "frame": frame,
        "location": _rounded_vector(matrix.translation),
        "rotation_quaternion_wxyz": _rounded_vector(quaternion),
        "lens_mm": round(float(getattr(data, "lens", 0.0)), 4),
        "sensor_width_mm": round(float(getattr(data, "sensor_width", 0.0)), 4),
        "shift_xy": [
            round(float(getattr(data, "shift_x", 0.0)), 5),
            round(float(getattr(data, "shift_y", 0.0)), 5),
        ],
    }


def _object_sample(scene, camera, obj, depsgraph, frame: int) -> dict:
    evaluated = obj.evaluated_get(depsgraph)
    matrix = evaluated.matrix_world
    location = _rounded_vector(matrix.translation)
    dimensions = _rounded_vector(evaluated.dimensions)
    hidden = bool(getattr(evaluated, "hide_render", False) or obj.hide_get())
    corners = []
    try:
        corners = [matrix @ Vector(corner) for corner in evaluated.bound_box]
    except (AttributeError, TypeError):
        corners = []
    projected = [world_to_camera_view(scene, camera, corner) for corner in corners]
    in_front = [point for point in projected if point.z > 0]
    if hidden or not in_front:
        return {
            "frame": frame, "projected_visible": False,
            "screen_bbox_percent": None, "depth": None,
            "world_location": location, "world_dimensions": dimensions,
        }
    min_x = min(point.x for point in in_front)
    max_x = max(point.x for point in in_front)
    min_y = min(point.y for point in in_front)
    max_y = max(point.y for point in in_front)
    intersects_frame = max_x > 0 and min_x < 1 and max_y > 0 and min_y < 1
    if not intersects_frame:
        return {
            "frame": frame, "projected_visible": False,
            "screen_bbox_percent": None,
            "depth": round(sum(point.z for point in in_front) / len(in_front), 5),
            "world_location": location, "world_dimensions": dimensions,
        }
    left = max(0.0, min(1.0, min_x))
    right = max(0.0, min(1.0, max_x))
    bottom = max(0.0, min(1.0, min_y))
    top = max(0.0, min(1.0, max_y))
    return {
        "frame": frame,
        "projected_visible": True,
        "screen_bbox_percent": {
            "center_x": round((left + right) * 50, 2),
            "center_y": round((2 - top - bottom) * 50, 2),
            "width": round((right - left) * 100, 2),
            "height": round((top - bottom) * 100, 2),
        },
        "depth": round(sum(point.z for point in in_front) / len(in_front), 5),
        "world_location": location,
        "world_dimensions": dimensions,
    }


def build_structure_evidence(
    scene=None, *, camera=None, frame_start: int, frame_end: int,
) -> dict | None:
    """Sample camera and renderable-object evidence without mutating the scene."""
    scene = scene or bpy.context.scene
    camera = camera or scene.camera
    if camera is None:
        raise SceneEvidenceError("scene has no camera")
    objects = sorted(
        (obj for obj in scene.objects if obj.type in RENDERABLE_TYPES),
        key=lambda item: (item.name.casefold(), item.name),
    )
    if not objects:
        return None
    if len(objects) > MAX_STRUCTURE_OBJECTS:
        raise SceneEvidenceError(
            f"scene has {len(objects)} renderable objects; maximum is {MAX_STRUCTURE_OBJECTS}"
        )
    frames = _sample_frames(frame_start, frame_end)
    current_frame = scene.frame_current
    current_subframe = scene.frame_subframe
    object_samples = [[] for _ in objects]
    camera_samples = []
    try:
        for frame in frames:
            scene.frame_set(frame)
            depsgraph = bpy.context.evaluated_depsgraph_get()
            evaluated_camera = camera.evaluated_get(depsgraph)
            camera_samples.append(_camera_sample(evaluated_camera, frame))
            for index, obj in enumerate(objects):
                object_samples[index].append(
                    _object_sample(scene, evaluated_camera, obj, depsgraph, frame)
                )
    finally:
        scene.frame_set(current_frame, subframe=current_subframe)
    evidence_objects = []
    for index, (obj, samples) in enumerate(zip(objects, object_samples), start=1):
        evidence_objects.append({
            "source_id": f"O{index:03d}",
            "name": obj.name,
            "object_type": obj.type,
            "parent_name": obj.parent.name if obj.parent else None,
            "root_name": _root_name(obj),
            "collection_names": sorted(collection.name for collection in obj.users_collection),
            "ever_projected_visible": any(sample["projected_visible"] for sample in samples),
            "samples": samples,
        })
    return {
        "schema_version": STRUCTURE_EVIDENCE_SCHEMA_VERSION,
        "sample_frames": frames,
        "camera_samples": camera_samples,
        "objects": evidence_objects,
    }


def inspect_scene(scene=None) -> dict:
    scene = scene or bpy.context.scene
    cameras = [obj.name for obj in scene.objects if obj.type == "CAMERA"]
    return {
        "scene_name": scene.name,
        "blend_file": bpy.data.filepath or "",
        "active_camera": scene.camera.name if scene.camera else None,
        "cameras": cameras,
        "frame_start": scene.frame_start,
        "frame_end": scene.frame_end,
        "fps": scene.render.fps,
        "fps_base": scene.render.fps_base,
        "resolution_x": scene.render.resolution_x,
        "resolution_y": scene.render.resolution_y,
        "blender_version": bpy.app.version_string,
        "os_name": platform.system(),
        "arch": platform.machine(),
    }


def effective_fps(scene=None) -> int:
    scene = scene or bpy.context.scene
    return round(scene.render.fps / scene.render.fps_base)
