"""Restricted execution for copilot bpy scripts (pure stdlib, no bpy).

Deny-by-default builtins: no import machinery, no filesystem/process access,
no eval/exec/compile. Callers inject exactly the objects a script may touch
(`bpy`, `math`, ...) via extra_globals. A settrace-based watchdog interrupts
runaway *Python-level* loops after timeout_s; a single long-running C call
(e.g. one heavy bpy operator) cannot be preempted — the bridge-side command
deadline remains the outer safety net for that case.

stdout and error text are always passed through utils.redaction.redact so
tokens or secrets echoed by a script never reach logs or the bridge.
"""
from __future__ import annotations

import io
import sys
import time
import traceback
from contextlib import redirect_stdout
from dataclasses import dataclass
from typing import Any, Dict, Optional

from ..utils.redaction import redact


class ScriptTimeout(RuntimeError):
    """Raised inside the traced script when the deadline passes."""


_ALLOWED_BUILTIN_NAMES = (
    "abs", "all", "any", "bool", "bytes", "callable", "chr", "dict", "dir",
    "divmod", "enumerate", "filter", "float", "format", "frozenset",
    "getattr", "hasattr", "hash", "hex", "int", "isinstance", "issubclass",
    "iter", "len", "list", "map", "max", "min", "next", "object", "oct",
    "ord", "pow", "print", "range", "repr", "reversed", "round", "set",
    "setattr", "slice", "sorted", "str", "sum", "tuple", "type", "zip",
    # Exceptions a well-behaved script may raise or catch.
    "ArithmeticError", "AttributeError", "BaseException", "Exception",
    "IndexError", "KeyError", "LookupError", "NameError", "NotImplementedError",
    "OverflowError", "RuntimeError", "StopIteration", "TypeError",
    "ValueError", "ZeroDivisionError",
    "True", "False", "None",
)


def _safe_builtins() -> Dict[str, Any]:
    import builtins

    allowed: Dict[str, Any] = {}
    for name in _ALLOWED_BUILTIN_NAMES:
        if hasattr(builtins, name):
            allowed[name] = getattr(builtins, name)
    return allowed


@dataclass
class ScriptResult:
    ok: bool
    stdout: str
    error: Optional[str] = None


def run_script(
    script: str,
    *,
    extra_globals: Optional[Dict[str, Any]] = None,
    timeout_s: float = 10.0,
) -> ScriptResult:
    """Execute `script` in a restricted namespace and report the outcome.

    Never raises for script-level failures; the caller gets a ScriptResult
    with redacted stdout/error either way.
    """
    namespace: Dict[str, Any] = {"__builtins__": _safe_builtins()}
    if extra_globals:
        namespace.update(extra_globals)

    deadline = time.monotonic() + max(timeout_s, 0.01)

    def _watchdog(frame, event, arg):  # noqa: ANN001 - trace protocol
        if time.monotonic() > deadline:
            raise ScriptTimeout(f"script exceeded {timeout_s}s")
        return _watchdog

    buffer = io.StringIO()
    previous_trace = sys.gettrace()
    sys.settrace(_watchdog)
    try:
        with redirect_stdout(buffer):
            code = compile(script, "<copilot_script>", "exec")
            exec(code, namespace)  # noqa: S102 - the whole point, gated above
        return ScriptResult(ok=True, stdout=redact(buffer.getvalue()))
    except ScriptTimeout as exc:
        return ScriptResult(
            ok=False,
            stdout=redact(buffer.getvalue()),
            error=redact(f"{ScriptTimeout.__name__}: {exc}"),
        )
    except SyntaxError as exc:
        return ScriptResult(
            ok=False,
            stdout=redact(buffer.getvalue()),
            error=redact(f"SyntaxError: {exc}"),
        )
    except BaseException as exc:  # noqa: BLE001 - report, never crash Blender
        detail = traceback.format_exception_only(type(exc), exc)
        return ScriptResult(
            ok=False,
            stdout=redact(buffer.getvalue()),
            error=redact("".join(detail).strip()),
        )
    finally:
        sys.settrace(previous_trace)
