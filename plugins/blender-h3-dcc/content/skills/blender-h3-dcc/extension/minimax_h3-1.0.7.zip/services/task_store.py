"""Persistent local record of drafts created from this machine.

Lets Blender re-attach to M Code-owned tasks after a restart. Stores no
tokens — sessions are re-created on demand; only draft ids and display
metadata are kept.
"""
from __future__ import annotations

import json
import os
import tempfile
from typing import Dict, List, Optional

STORE_SCHEMA_VERSION = 1


def default_store_path() -> str:
    base = os.environ.get("HAILUO_H3_STATE_DIR") or os.path.join(
        os.path.expanduser("~"), ".minimax_h3"
    )
    return os.path.join(base, "tasks.json")


class TaskStore:
    def __init__(self, path: Optional[str] = None) -> None:
        self.path = path or default_store_path()

    def _load(self) -> Dict:
        try:
            with open(self.path, "r", encoding="utf-8") as f:
                data = json.load(f)
            if not isinstance(data, dict) or data.get("schema_version") != STORE_SCHEMA_VERSION:
                return {"schema_version": STORE_SCHEMA_VERSION, "drafts": []}
            return data
        except (OSError, json.JSONDecodeError):
            return {"schema_version": STORE_SCHEMA_VERSION, "drafts": []}

    def _save(self, data: Dict) -> None:
        os.makedirs(os.path.dirname(self.path), exist_ok=True)
        fd, tmp = tempfile.mkstemp(dir=os.path.dirname(self.path), suffix=".tmp")
        try:
            with os.fdopen(fd, "w", encoding="utf-8") as f:
                json.dump(data, f, ensure_ascii=False, indent=1)
            os.replace(tmp, self.path)
        except OSError:
            try:
                os.remove(tmp)
            except OSError:
                pass
            raise

    def record_draft(self, *, draft_id: str, state: str, deep_link: str,
                     scene_name: str, created_at_ms: int) -> None:
        data = self._load()
        drafts: List[Dict] = data["drafts"]
        for entry in drafts:
            if entry.get("draft_id") == draft_id:
                entry.update(state=state, deep_link=deep_link)
                break
        else:
            drafts.append({
                "draft_id": draft_id,
                "state": state,
                "deep_link": deep_link,
                "scene_name": scene_name,
                "created_at_ms": created_at_ms,
            })
        self._save(data)

    def update_state(self, draft_id: str, state: str) -> None:
        data = self._load()
        for entry in data["drafts"]:
            if entry.get("draft_id") == draft_id:
                entry["state"] = state
                self._save(data)
                return

    def list_drafts(self) -> List[Dict]:
        return list(self._load()["drafts"])

    def latest_draft(self) -> Optional[Dict]:
        drafts = self.list_drafts()
        if not drafts:
            return None
        return max(drafts, key=lambda d: d.get("created_at_ms", 0))
