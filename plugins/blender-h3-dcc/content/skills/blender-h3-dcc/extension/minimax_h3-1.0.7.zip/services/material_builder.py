"""Build Principled BSDF materials from a validated spec (requires bpy).

Takes the structured spec from models.material_spec (already normalized) and
assembles a node graph: Principled BSDF -> Material Output, plus one Image
Texture node per filled texture slot (normal maps go through a Normal Map
node). No generation, no network — texture paths must already exist locally.

Functions are deliberately side-effect-scoped: build_material only touches
bpy.data.materials, apply_material_spec additionally assigns to one object.
Both are headless-testable.
"""
from __future__ import annotations

from typing import Any, Dict

import bpy

from ..models.material_spec import normalize_material_spec

_TEXTURE_TARGET_INPUTS = {
    "base_color": "Base Color",
    "metallic": "Metallic",
    "roughness": "Roughness",
}


def build_material(spec: Dict[str, Any]) -> "bpy.types.Material":
    """Create (or replace) a material from a spec and return it."""
    normalized = normalize_material_spec(spec, check_files=True)

    name = normalized["name"]
    material = bpy.data.materials.get(name)
    if material is None:
        material = bpy.data.materials.new(name)
    material.use_nodes = True
    tree = material.node_tree
    tree.nodes.clear()

    output = tree.nodes.new("ShaderNodeOutputMaterial")
    output.location = (400, 0)
    bsdf = tree.nodes.new("ShaderNodeBsdfPrincipled")
    bsdf.location = (0, 0)
    tree.links.new(bsdf.outputs["BSDF"], output.inputs["Surface"])

    bsdf.inputs["Base Color"].default_value = normalized["base_color"]
    bsdf.inputs["Metallic"].default_value = normalized["metallic"]
    bsdf.inputs["Roughness"].default_value = normalized["roughness"]
    if "Emission Color" in bsdf.inputs:  # Blender 4.x/5.x naming
        bsdf.inputs["Emission Color"].default_value = normalized["emission_color"]
    elif "Emission" in bsdf.inputs:
        bsdf.inputs["Emission"].default_value = normalized["emission_color"]
    if "Emission Strength" in bsdf.inputs:
        bsdf.inputs["Emission Strength"].default_value = normalized["emission_strength"]

    y_offset = 300
    for slot, path in normalized["textures"].items():
        image = bpy.data.images.load(path, check_existing=True)
        tex_node = tree.nodes.new("ShaderNodeTexImage")
        tex_node.location = (-400, y_offset)
        tex_node.image = image
        tex_node.label = f"copilot:{slot}"
        if slot == "normal":
            image.colorspace_settings.name = "Non-Color"
            normal_map = tree.nodes.new("ShaderNodeNormalMap")
            normal_map.location = (-200, y_offset)
            tree.links.new(tex_node.outputs["Color"], normal_map.inputs["Color"])
            tree.links.new(normal_map.outputs["Normal"], bsdf.inputs["Normal"])
        else:
            if slot != "base_color":
                image.colorspace_settings.name = "Non-Color"
            tree.links.new(
                tex_node.outputs["Color"],
                bsdf.inputs[_TEXTURE_TARGET_INPUTS[slot]],
            )
        y_offset -= 300

    return material


def apply_material_spec(obj, spec: Dict[str, Any]) -> "bpy.types.Material":
    """Build the material and assign it to slot 0 of the given object."""
    if obj is None or obj.type != "MESH":
        raise ValueError("material specs can only be applied to mesh objects")
    material = build_material(spec)
    if obj.data.materials:
        obj.data.materials[0] = material
    else:
        obj.data.materials.append(material)
    return material
