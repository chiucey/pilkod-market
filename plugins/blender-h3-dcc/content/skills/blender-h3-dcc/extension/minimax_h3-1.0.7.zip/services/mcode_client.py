"""Client for the M Code DCC bridge.

Transport: JSON-line over a Unix domain socket (macOS/Linux). On Windows the
same line protocol runs over a named pipe; that transport lands together
with the Windows validation pass. There is deliberately no TCP: the bridge
follows the mavis-browser broker precedent (profile-derived socket path,
filesystem permissions as the auth boundary, short-lived session tokens on
top).

Retry policy: only idempotent read ops (health, task_status) are retried.
submit_draft is never retried by the client; double-click safety comes from
the deterministic submit_key instead.
"""
from __future__ import annotations

import hashlib
import json
import os
import socket
import sys
from typing import Any, Dict, List, Optional

PROTOCOL_VERSION = 1
_IDEMPOTENT_OPS = frozenset({"health", "task_status"})


class MCodeUnavailable(RuntimeError):
    """Bridge socket missing, connection refused, or connection dropped."""


class MCodeTimeout(RuntimeError):
    """Bridge did not answer within the configured timeout."""


class BridgeError(RuntimeError):
    """Bridge answered with ok=false."""

    def __init__(self, code: str, message: str) -> None:
        super().__init__(f"{code}: {message}")
        self.code = code
        self.bridge_message = message


class SessionExpired(BridgeError):
    pass


def default_data_dir() -> str:
    return os.environ.get("MAVIS_DATA_DIR") or os.path.join(
        os.path.expanduser("~"), ".mavis"
    )


# AF_UNIX sun_path is 104 bytes on macOS and 108 on Linux, including the
# trailing NUL. Mirrors dccBridgeSocketPath in local-runtime/src/dcc/bridge.ts;
# both ends must derive the same path or the client silently misses the bridge.
_SOCKET_PATH_LIMIT = 104 if sys.platform == "darwin" else 108


def socket_path_for(data_dir: str) -> str:
    if os.name == "nt":
        tag = hashlib.sha256(data_dir.encode("utf-8")).hexdigest()[:12]
        return r"\\.\pipe\mavis-dcc-{0}".format(tag)
    preferred = os.path.join(data_dir, "dcc-bridge.sock")
    if len(preferred.encode("utf-8")) + 1 <= _SOCKET_PATH_LIMIT:
        return preferred
    tag = hashlib.sha256(data_dir.encode("utf-8")).hexdigest()[:12]
    return os.path.join(os.path.expanduser("~"), ".mavis-dcc", "{0}.sock".format(tag))


def default_socket_path() -> str:
    env = os.environ.get("MAVIS_DCC_BRIDGE_SOCKET")
    if env:
        return env
    return socket_path_for(default_data_dir())


def make_submit_key(session_id: str, manifest_hash: str) -> str:
    """Deterministic idempotency key: same manifest in the same session
    always maps to the same draft, so repeated clicks cannot double-bill."""
    return hashlib.sha256(f"{session_id}:{manifest_hash}".encode("utf-8")).hexdigest()


class MCodeClient:
    def __init__(
        self,
        socket_path: Optional[str] = None,
        timeout: float = 10.0,
        retries: int = 1,
    ) -> None:
        self.socket_path = socket_path or default_socket_path()
        self.timeout = timeout
        self.retries = max(0, retries)
        self._id = 0

    # -- transport -------------------------------------------------------
    def _request_once(self, payload: Dict[str, Any]) -> Dict[str, Any]:
        if not hasattr(socket, "AF_UNIX"):
            # Windows: the bridge protocol runs over a named pipe there, and
            # that client transport has not landed yet (see module docstring).
            # Raise the normal "unreachable" error so callers degrade to the
            # copy-paste channel instead of crashing on AttributeError.
            raise MCodeUnavailable("named-pipe transport not yet implemented")
        sock = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
        sock.settimeout(self.timeout)
        try:
            try:
                sock.connect(self.socket_path)
            except (FileNotFoundError, ConnectionRefusedError, PermissionError) as exc:
                raise MCodeUnavailable(f"bridge not reachable: {exc}") from exc
            try:
                sock.sendall((json.dumps(payload) + "\n").encode("utf-8"))
                buf = b""
                while not buf.endswith(b"\n"):
                    chunk = sock.recv(65536)
                    if not chunk:
                        raise MCodeUnavailable("bridge closed the connection")
                    buf += chunk
            except socket.timeout as exc:
                raise MCodeTimeout(
                    f"bridge did not answer within {self.timeout}s"
                ) from exc
            except (BrokenPipeError, ConnectionResetError) as exc:
                raise MCodeUnavailable(f"bridge connection lost: {exc}") from exc
        finally:
            sock.close()
        try:
            response = json.loads(buf.decode("utf-8"))
        except (UnicodeDecodeError, json.JSONDecodeError) as exc:
            raise MCodeUnavailable(f"bridge sent malformed response: {exc}") from exc
        if not isinstance(response, dict):
            raise MCodeUnavailable("bridge sent a non-object response")
        return response

    def _request(self, op: str, **fields: Any) -> Dict[str, Any]:
        self._id += 1
        payload: Dict[str, Any] = {"id": self._id, "op": op}
        payload.update(fields)
        attempts = 1 + (self.retries if op in _IDEMPOTENT_OPS else 0)
        last_exc: Optional[Exception] = None
        for _ in range(attempts):
            try:
                response = self._request_once(payload)
                break
            except MCodeUnavailable as exc:
                last_exc = exc
        else:
            assert last_exc is not None
            raise last_exc
        if not response.get("ok"):
            error = response.get("error") or {}
            code = str(error.get("code", "unknown"))
            message = str(error.get("message", ""))
            if code == "session_expired":
                raise SessionExpired(code, message)
            raise BridgeError(code, message)
        return response

    # -- ops -------------------------------------------------------------
    def health(self) -> Dict[str, Any]:
        return self._request("health")

    def create_session(self, *, addon_version: str, blender_version: str) -> Dict[str, Any]:
        return self._request(
            "create_session",
            client={"addon_version": addon_version, "blender_version": blender_version},
        )

    def submit_draft(
        self,
        session: Dict[str, Any],
        *,
        manifest_payload: Dict[str, Any],
        manifest_hash: str,
        files: List[Dict[str, Any]],
    ) -> Dict[str, Any]:
        return self._request(
            "submit_draft",
            session_id=session["session_id"],
            session_token=session["session_token"],
            submit_key=make_submit_key(session["session_id"], manifest_hash),
            manifest=manifest_payload,
            manifest_hash=manifest_hash,
            files=files,
        )

    def task_status(self, session: Dict[str, Any], *, draft_id: str) -> Dict[str, Any]:
        return self._request(
            "task_status",
            session_id=session["session_id"],
            session_token=session["session_token"],
            draft_id=draft_id,
        )

    # -- copilot command plane --------------------------------------------
    # Direction is inverted here: M Code enqueues commands, Blender claims
    # them. Neither op is retried — fetch_command claims (mutates) and
    # command_result must reach the bridge exactly once per execution.
    def fetch_command(self, session: Dict[str, Any]) -> Dict[str, Any]:
        return self._request(
            "fetch_command",
            session_id=session["session_id"],
            session_token=session["session_token"],
        )

    def command_result(
        self,
        session: Dict[str, Any],
        *,
        command_id: str,
        ok: bool,
        result: Optional[Dict[str, Any]] = None,
        error: Optional[str] = None,
        approval_token: Optional[str] = None,
    ) -> Dict[str, Any]:
        fields: Dict[str, Any] = {
            "session_id": session["session_id"],
            "session_token": session["session_token"],
            "command_id": command_id,
            "ok": ok,
        }
        if result is not None:
            fields["result"] = result
        if error is not None:
            fields["error"] = error
        if approval_token is not None:
            fields["approval_token"] = approval_token
        return self._request("command_result", **fields)
