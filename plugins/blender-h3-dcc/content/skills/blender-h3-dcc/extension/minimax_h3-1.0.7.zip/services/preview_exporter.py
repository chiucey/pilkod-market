"""Deterministic preview export driven by the scene camera and timeline.

This is an offscreen render through the active camera — never a screen
recording, so no Blender UI or mouse can appear in the output.

Modes:
- white_model: Workbench engine, single flat color, studio lighting. Does not
  touch user materials or objects.
- material_preview: EEVEE render honoring current visibility and materials.

Every scene/render setting we touch is snapshotted first and restored on
success, failure, and cancellation alike.
"""
from __future__ import annotations

import os
from contextlib import contextmanager
from typing import Callable, List, Optional, Sequence

import bpy

from .shot_batch import ShotExportResult, export_shot_batch
from .shot_planner import Shot

RESOLUTION_PRESETS = {
    "360P": (640, 360),
    "480P": (854, 480),
    "720P": (1280, 720),
    "1080P": (1920, 1080),
}

# (owner attribute path, setting names) — everything we mutate for export.
_SCENE_SETTINGS = (
    "frame_start", "frame_end", "frame_step",
)
_RENDER_SETTINGS = (
    "engine", "filepath", "resolution_x", "resolution_y",
    "resolution_percentage", "fps", "fps_base", "film_transparent",
    "use_file_extension", "use_overwrite", "use_placeholder",
)
_IMAGE_SETTINGS = ("media_type", "file_format", "color_mode")
_FFMPEG_SETTINGS = ("format", "codec", "constant_rate_factor", "ffmpeg_preset",
                    "gopsize", "audio_codec")
_SHADING_SETTINGS = ("light", "color_type", "show_object_outline",
                     "show_cavity", "use_dof", "show_shadows")


class ExportCancelled(RuntimeError):
    pass


class ExportError(RuntimeError):
    pass


def _snapshot(obj, names):
    return {name: getattr(obj, name) for name in names if hasattr(obj, name)}


def _restore(obj, snapshot):
    for name, value in snapshot.items():
        try:
            setattr(obj, name, value)
        except Exception:
            # Restoring must keep going even if one attribute became
            # read-only (e.g. engine-dependent settings).
            pass


@contextmanager
def preserved_export_settings(scene):
    render = scene.render
    saved = {
        "scene": _snapshot(scene, _SCENE_SETTINGS),
        "render": _snapshot(render, _RENDER_SETTINGS),
        "image": _snapshot(render.image_settings, _IMAGE_SETTINGS),
        "camera": scene.camera,
        "shading": _snapshot(scene.display.shading, _SHADING_SETTINGS)
        if hasattr(scene, "display") else {},
        "ffmpeg": _snapshot(render.ffmpeg, _FFMPEG_SETTINGS)
        if hasattr(render, "ffmpeg") else {},
    }
    try:
        yield
    finally:
        _restore(scene, saved["scene"])
        _restore(render, saved["render"])
        _restore(render.image_settings, saved["image"])
        if saved["ffmpeg"]:
            _restore(render.ffmpeg, saved["ffmpeg"])
        if saved["shading"]:
            _restore(scene.display.shading, saved["shading"])
        scene.camera = saved["camera"]


def _apply_common(scene, *, camera, frame_start, frame_end, fps, resolution,
                  output_path):
    render = scene.render
    scene.camera = camera
    scene.frame_start = frame_start
    scene.frame_end = frame_end
    scene.frame_step = 1
    if resolution != "original":
        width, height = RESOLUTION_PRESETS[resolution]
        render.resolution_x = width
        render.resolution_y = height
    render.resolution_percentage = 100
    render.fps = fps
    render.fps_base = 1.0
    render.film_transparent = False
    render.filepath = output_path
    render.use_file_extension = False
    render.use_overwrite = True
    render.use_placeholder = False
    if hasattr(render.image_settings, "media_type"):
        # Blender 5.x gates movie formats behind media_type; 4.x exposes
        # FFMPEG in file_format directly.
        render.image_settings.media_type = "VIDEO"
    render.image_settings.file_format = "FFMPEG"
    render.image_settings.color_mode = "RGB"
    render.ffmpeg.format = "MPEG4"
    render.ffmpeg.codec = "H264"
    render.ffmpeg.constant_rate_factor = "MEDIUM"
    render.ffmpeg.ffmpeg_preset = "GOOD"
    render.ffmpeg.audio_codec = "NONE"


def _apply_white_model(scene):
    scene.render.engine = "BLENDER_WORKBENCH"
    shading = scene.display.shading
    shading.light = "STUDIO"
    shading.color_type = "SINGLE"
    shading.show_object_outline = False
    shading.show_cavity = False
    shading.use_dof = False
    shading.show_shadows = True


def _apply_material_preview(scene):
    engines = {"BLENDER_EEVEE_NEXT", "BLENDER_EEVEE"}
    available = {
        item.identifier
        for item in bpy.types.RenderSettings.bl_rna.properties["engine"].enum_items
    }
    for engine in engines:
        if engine in available:
            scene.render.engine = engine
            return
    raise ExportError("no EEVEE engine available for material preview")


def export_preview(
    *,
    scene=None,
    camera=None,
    frame_start: int,
    frame_end: int,
    fps: int,
    resolution: str,
    export_mode: str,
    output_path: str,
) -> str:
    """Render the camera animation to an MP4. Returns the output path.

    Runs a blocking animation render — callers in interactive Blender should
    invoke it from an operator; headless callers (tests, installer
    verification) call it directly.
    """
    scene = scene or bpy.context.scene
    camera = camera or scene.camera
    if camera is None:
        raise ExportError("scene has no camera")
    if frame_end < frame_start:
        raise ExportError("frame_end < frame_start")
    if resolution != "original" and resolution not in RESOLUTION_PRESETS:
        raise ExportError(f"unknown resolution preset: {resolution}")

    out_dir = os.path.dirname(output_path)
    if out_dir:
        os.makedirs(out_dir, exist_ok=True)

    with preserved_export_settings(scene):
        _apply_common(
            scene, camera=camera, frame_start=frame_start, frame_end=frame_end,
            fps=fps, resolution=resolution, output_path=output_path,
        )
        if export_mode == "white_model":
            _apply_white_model(scene)
        elif export_mode == "material_preview":
            _apply_material_preview(scene)
        else:
            raise ExportError(f"unsupported export mode: {export_mode}")

        result = bpy.ops.render.render(animation=True)
        if "CANCELLED" in result:
            _cleanup_partial(output_path)
            raise ExportCancelled("render was cancelled")

    if not os.path.isfile(output_path) or os.path.getsize(output_path) == 0:
        _cleanup_partial(output_path)
        raise ExportError("export produced no output file")
    return output_path


def _cleanup_partial(output_path: str) -> None:
    try:
        if os.path.isfile(output_path):
            os.remove(output_path)
    except OSError:
        pass


def export_shot_previews(
    *,
    scene=None,
    shots: Sequence[Shot],
    fps: int,
    resolution: str,
    export_mode: str,
    output_dir: str,
    is_cancelled: Optional[Callable[[], bool]] = None,
) -> List[ShotExportResult]:
    """Export one preview MP4 per shot (shot camera + shot frame range).

    Cancellation (via is_cancelled or a cancelled render) raises
    ShotBatchCancelled; a failed shot raises ShotBatchError. Both keep the
    already-completed shot files and carry them on the exception.
    """
    scene = scene or bpy.context.scene

    def _export_one(shot: Shot, output_path: str) -> str:
        camera = scene.objects.get(shot.camera_name)
        if camera is None:
            raise ExportError(
                f"shot {shot.index} camera not found: {shot.camera_name!r}"
            )
        return export_preview(
            scene=scene, camera=camera,
            frame_start=shot.frame_start, frame_end=shot.frame_end,
            fps=fps, resolution=resolution, export_mode=export_mode,
            output_path=output_path,
        )

    return export_shot_batch(
        shots,
        export_fn=_export_one,
        output_dir=output_dir,
        is_cancelled=is_cancelled,
        cancel_exceptions=(KeyboardInterrupt, ExportCancelled),
    )
