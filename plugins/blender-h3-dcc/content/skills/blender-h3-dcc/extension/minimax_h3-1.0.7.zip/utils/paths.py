"""Path normalization and outgoing-file validation.

Every file handed to the M Code bridge must resolve inside an allowed root
(no traversal, no symlink escape) and match the extension/MIME/size rules
for its manifest role.
"""
from __future__ import annotations

import hashlib
import os
from dataclasses import dataclass

ALLOWED_VIDEO_EXTENSIONS = frozenset({".mp4", ".mov"})
ALLOWED_IMAGE_EXTENSIONS = frozenset({".png", ".jpg", ".jpeg", ".webp"})

MAX_VIDEO_BYTES = 512 * 1024 * 1024
MAX_IMAGE_BYTES = 20 * 1024 * 1024

_MIME_BY_EXTENSION = {
    ".mp4": "video/mp4",
    ".mov": "video/quicktime",
    ".png": "image/png",
    ".jpg": "image/jpeg",
    ".jpeg": "image/jpeg",
    ".webp": "image/webp",
}

_VIDEO_ROLES = frozenset({"preview_video"})
_IMAGE_ROLES = frozenset({"character_reference", "scene_reference", "style_reference"})


class PathValidationError(ValueError):
    pass


@dataclass
class OutgoingFileInfo:
    path: str
    name: str
    size_bytes: int
    sha256: str
    mime: str


def _sha256_of(path: str) -> str:
    digest = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def validate_outgoing_file(
    path: str,
    *,
    role: str,
    allowed_root: str,
    max_bytes: int | None = None,
) -> OutgoingFileInfo:
    if role in _VIDEO_ROLES:
        allowed_extensions = ALLOWED_VIDEO_EXTENSIONS
        default_max = MAX_VIDEO_BYTES
    elif role in _IMAGE_ROLES:
        allowed_extensions = ALLOWED_IMAGE_EXTENSIONS
        default_max = MAX_IMAGE_BYTES
    else:
        raise PathValidationError(f"unknown role: {role!r}")
    limit = max_bytes if max_bytes is not None else default_max

    real_root = os.path.realpath(allowed_root)
    real_path = os.path.realpath(path)
    if not os.path.isfile(real_path):
        raise PathValidationError(f"not a regular file: {path!r}")
    if os.path.commonpath([real_root, real_path]) != real_root:
        raise PathValidationError(
            f"file resolves outside the allowed root: {path!r}"
        )

    name = os.path.basename(real_path)
    ext = os.path.splitext(name)[1].lower()
    if ext not in allowed_extensions:
        raise PathValidationError(
            f"extension {ext!r} not allowed for role {role!r}"
        )

    size = os.path.getsize(real_path)
    if size <= 0:
        raise PathValidationError(f"file is empty: {path!r}")
    if size > limit:
        raise PathValidationError(
            f"file too large for role {role!r}: {size} > {limit} bytes"
        )

    return OutgoingFileInfo(
        path=real_path,
        name=name,
        size_bytes=size,
        sha256=_sha256_of(real_path),
        mime=_MIME_BY_EXTENSION[ext],
    )
