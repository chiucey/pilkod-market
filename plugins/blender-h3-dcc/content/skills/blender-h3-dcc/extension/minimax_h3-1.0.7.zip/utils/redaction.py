"""Log redaction: no token, cookie, key, or authorization material in logs."""
from __future__ import annotations

import re

_REDACTED = "[REDACTED]"

_PATTERNS = [
    # Authorization: Bearer <token> / bare "Bearer xyz"
    (re.compile(r"(?i)\bbearer\s+[A-Za-z0-9\-._~+/=]+"), f"Bearer {_REDACTED}"),
    # JSON-ish fields: "token": "value"
    (
        re.compile(
            r"(?i)([\"']?(?:[a-z0-9_]*token|api[_-]?key|access[_-]?key|"
            r"secret[a-z0-9_]*|password|cookie|authorization)[\"']?\s*[:=]\s*)"
            r"([\"'])(?:(?!\2).)*\2"
        ),
        lambda m: f"{m.group(1)}{m.group(2)}{_REDACTED}{m.group(2)}",
    ),
    # Query-string style: ?session_token=abc / &key=... / &secret=...
    (
        re.compile(
            r"(?i)([?&](?:[a-z0-9_]*token|[a-z0-9_]*key|[a-z0-9_]*secret|"
            r"auth[a-z0-9_]*)=)[^&\s]+"
        ),
        lambda m: f"{m.group(1)}{_REDACTED}",
    ),
    # Cookie / Set-Cookie header values
    (
        re.compile(r"(?i)\b((?:set-)?cookie\s*:\s*).+"),
        lambda m: f"{m.group(1)}{_REDACTED}",
    ),
]


def redact(value: object) -> str:
    text = value if isinstance(value, str) else str(value)
    for pattern, replacement in _PATTERNS:
        text = pattern.sub(replacement, text)
    return text
